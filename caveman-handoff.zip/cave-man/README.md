# CAVE MAN — The First Tower

A room-based prehistoric roguelike inspired by The Binding of Isaac. Farm materials, craft your build, fight the Tower guardians. Runs in any browser — desktop or phone, no install.

**Play it:** open `index.html` in a browser, or publish with GitHub Pages (see below) to play on your phone from a link.

## Controls

Desktop (Player 1): WASD to move, mouse to aim, click or Space to throw, Q/E for crafted tools, C to open crafting, Escape or P to pause.

Desktop (Player 2, "Two Hunters" mode): Arrow keys to move, Enter to throw, Right-Shift and Right-Ctrl for tools.

Phone: left thumb is a virtual joystick for moving. Right side depends on the aiming mode picked on the title screen — Auto-Aim gives you one big throw button (the game aims at the nearest beast), Twin-Stick gives you a second joystick that aims and fires. Tap the tool circles for your crafted tools, the flint button to craft, and the pause button top-left.

## Title screen parameters

Aiming mode (Auto-Aim / Twin-Stick), difficulty (Cub / Hunter / Urm's Chosen — scales beast health, damage and hunger drain), and sound on/off. The pause menu offers Resume, Restart Room, Restart Run, and Title Screen.

## Project structure

```
cave-man/
├── index.html      page shell — loads the style and the game
├── css/style.css   menus, overlays, HUD text styling
└── js/game.js      the entire game: sprites, rooms, AI, crafting, touch controls
```

Everything is plain HTML/CSS/JavaScript with zero dependencies, so it works offline from a double-click and deploys anywhere static files can be hosted.

## Push this to your GitHub repo

From inside the `cave-man` folder:

```bash
git init
git remote add origin https://github.com/SeederOfLife/Cave-man.git
git add .
git commit -m "Cave Man v6: smooth art, mobile controls, pause menu, difficulty"
git push -u origin main --force
```

(`--force` replaces the old Godot experiment files with this version — drop it if you want to keep the history.)

## Publish to phone with GitHub Pages

GitHub Pages is a free feature that turns your repo into a website. Once enabled, anyone (including your phone) can play the game at a normal web link — no file transfer needed.

1. Push the code (above).
2. On GitHub: repo → **Settings** → **Pages**.
3. Under "Build and deployment", set Source to **Deploy from a branch**, pick branch **main** and folder **/ (root)**, save.
4. Wait about a minute. The game will be live at `https://seederoflife.github.io/Cave-man/`.
5. Open that link on your phone, and optionally use your browser's "Add to Home Screen" so it launches like an app.

## Roadmap

The MOBA vision (dungeon-farming, then racing or fighting to the top of the First Tower) is documented in the design lore. Current build covers: farm loop, craft loadout (2 active tools / 3 passive crafts), Tower bosses every 3 caves, and local 2-player co-op. Next big step is a WebSocket server for online play.
