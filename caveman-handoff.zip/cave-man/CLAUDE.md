# CLAUDE.md — working rules for AI agents on Cave Man

Read `../HANDOFF.md` for the full architecture before touching code. Read `../CAVEMAN_LORE.md` before writing any player-facing text, item, or enemy — everything must fit the world (Urm the silent mountain god, the First Tower, slither-men, caveman-speak in ALL CAPS for game messages, Grok talks in third person).

## Project rules

The game is plain HTML/CSS/JS with zero dependencies and must keep working offline from a double-click on `index.html`. Do not add frameworks, build steps, npm packages, module bundlers, or external assets (images, fonts, audio files). All art is procedural vector drawing pre-rendered via `mkS()` in `js/game.js`; all new sprites must go through the `outlined()` pass for the cel-outline look. All sound is synthesized in `sfx()`.

Keep the entire game in `js/game.js` — it is organized in labeled comment sections; add code to the matching section. Sizes, speeds and radii must be expressed in `TILE` units, never hardcoded pixels, so the game scales to any screen. Every render pass must start with `resetT(ctx)` (DPR-aware), never raw `setTransform`.

Any change must work for all four play modes: desktop solo, desktop 2-player (shared keyboard), phone auto-aim, phone twin-stick. New interactive elements need both a keyboard path and a touch hitbox (register buttons in `touch.btns` inside `drawTouchUI`, or rows in `touch.panelRows` for panels).

Never remove `keepInRoom()` or its call sites — it prevents entities escaping rooms after knockback.

## Gameplay invariants

Crafting limits are core design: maximum 2 active tools and 3 passive crafts per run ("choose like a hunter"). Materials are the economy — new content should feed it (new destructibles drop materials, new enemies have drop tables in `dropLoot`). Tower floors appear after cave depths divisible by 3 and must always contain a guardian that seals the exit hole until killed. Downed co-op players revive with 1 heart at the next room transition; the run ends only when all players are down.

## Testing before declaring done

Syntax-check with `node --check js/game.js`. For logic, the codebase supports headless smoke tests: stub `window/document/canvas`, eval the file, then call `start(1)`, run `update(1/60)` in a loop, and assert on `game` state (see HANDOFF.md; prior tests covered movement, craft limits, tower flow, and containment — keep that bar). Manually verify in a browser: one full cave floor, one craft, one tower fight, and the pause menu's Restart Room in both a cave room and a Tower room.
