"use strict";
/* =====================================================================
   CAVE MAN v5 — smooth vector art · mobile touch · auto-aim/twin-stick
   ===================================================================== */

// ---------- canvas & DPR ----------
const cvs=document.getElementById('game');
const ctx=cvs.getContext('2d');
const lightCvs=document.createElement('canvas');
const lctx=lightCvs.getContext('2d');
let VW=960,VH=600,DPR=1;
function resetT(c){c.setTransform(DPR,0,0,DPR,0,0);}
function resize(){
  DPR=Math.min(window.devicePixelRatio||1,2);
  VW=window.innerWidth;VH=window.innerHeight;
  cvs.width=VW*DPR;cvs.height=VH*DPR;
  cvs.style.width=VW+'px';cvs.style.height=VH+'px';
  lightCvs.width=VW*DPR;lightCvs.height=VH*DPR;
  ctx.imageSmoothingEnabled=true;lctx.imageSmoothingEnabled=true;
  if(game)computeLayout(true);
}
window.addEventListener('resize',resize);
const IS_TOUCH=('ontouchstart' in window)||navigator.maxTouchPoints>0;

// ---------- sfx ----------
let AC=null;
function audio(){if(!AC)AC=new (window.AudioContext||window.webkitAudioContext)();return AC;}
function sfx(type){
  if(!soundOn)return;
  try{
    const ac=audio(),t=ac.currentTime;
    const o=ac.createOscillator(),g=ac.createGain();
    o.connect(g);g.connect(ac.destination);
    const P={
      throw:()=>{o.type='square';o.frequency.setValueAtTime(340,t);o.frequency.exponentialRampToValueAtTime(120,t+.12);g.gain.setValueAtTime(.05,t);g.gain.exponentialRampToValueAtTime(.001,t+.12);o.stop(t+.13);},
      hit:()=>{o.type='sawtooth';o.frequency.setValueAtTime(160,t);o.frequency.exponentialRampToValueAtTime(60,t+.1);g.gain.setValueAtTime(.08,t);g.gain.exponentialRampToValueAtTime(.001,t+.1);o.stop(t+.11);},
      rock:()=>{o.type='square';o.frequency.setValueAtTime(90,t);o.frequency.exponentialRampToValueAtTime(40,t+.08);g.gain.setValueAtTime(.06,t);g.gain.exponentialRampToValueAtTime(.001,t+.08);o.stop(t+.09);},
      pickup:()=>{o.type='triangle';o.frequency.setValueAtTime(420,t);o.frequency.setValueAtTime(640,t+.07);g.gain.setValueAtTime(.06,t);g.gain.exponentialRampToValueAtTime(.001,t+.18);o.stop(t+.19);},
      hurt:()=>{o.type='sawtooth';o.frequency.setValueAtTime(110,t);o.frequency.exponentialRampToValueAtTime(45,t+.22);g.gain.setValueAtTime(.1,t);g.gain.exponentialRampToValueAtTime(.001,t+.22);o.stop(t+.23);},
      die:()=>{o.type='sawtooth';o.frequency.setValueAtTime(220,t);o.frequency.exponentialRampToValueAtTime(30,t+.7);g.gain.setValueAtTime(.12,t);g.gain.exponentialRampToValueAtTime(.001,t+.7);o.stop(t+.72);},
      stairs:()=>{o.type='triangle';o.frequency.setValueAtTime(200,t);o.frequency.setValueAtTime(300,t+.1);o.frequency.setValueAtTime(450,t+.2);g.gain.setValueAtTime(.07,t);g.gain.exponentialRampToValueAtTime(.001,t+.4);o.stop(t+.42);},
      slam:()=>{o.type='square';o.frequency.setValueAtTime(70,t);o.frequency.exponentialRampToValueAtTime(35,t+.15);g.gain.setValueAtTime(.11,t);g.gain.exponentialRampToValueAtTime(.001,t+.15);o.stop(t+.16);},
      clear:()=>{o.type='triangle';o.frequency.setValueAtTime(330,t);o.frequency.setValueAtTime(440,t+.09);o.frequency.setValueAtTime(550,t+.18);g.gain.setValueAtTime(.07,t);g.gain.exponentialRampToValueAtTime(.001,t+.34);o.stop(t+.36);},
      grok:()=>{o.type='triangle';o.frequency.setValueAtTime(240,t);o.frequency.setValueAtTime(180,t+.12);g.gain.setValueAtTime(.06,t);g.gain.exponentialRampToValueAtTime(.001,t+.3);o.stop(t+.32);},
      boss:()=>{o.type='sawtooth';o.frequency.setValueAtTime(55,t);o.frequency.setValueAtTime(48,t+.25);o.frequency.setValueAtTime(40,t+.5);g.gain.setValueAtTime(.14,t);g.gain.exponentialRampToValueAtTime(.001,t+.8);o.stop(t+.82);},
    };
    (P[type]||P.hit)();o.start(t);
  }catch(e){}
}

// ---------- smooth vector sprites (pre-rendered) ----------
const S=96; // sprite canvas size
function mkS(fn,size){
  const sz=size||S;
  const c=document.createElement('canvas');c.width=sz;c.height=sz;
  const g=c.getContext('2d');g.imageSmoothingEnabled=true;
  fn(g,sz);return c;
}
function rg(g,x,y,r,c1,c2){const gr=g.createRadialGradient(x-r*.3,y-r*.35,r*.15,x,y,r);gr.addColorStop(0,c1);gr.addColorStop(1,c2);return gr;}
function ell(g,x,y,rx,ry,fill){g.fillStyle=fill;g.beginPath();g.ellipse(x,y,rx,ry,0,0,7);g.fill();}
function heartPath(g,s){
  g.beginPath();
  g.moveTo(s*.5,s*.88);
  g.bezierCurveTo(s*.08,s*.58,s*.04,s*.3,s*.28,s*.18);
  g.bezierCurveTo(s*.42,s*.11,s*.5,s*.24,s*.5,s*.32);
  g.bezierCurveTo(s*.5,s*.24,s*.58,s*.11,s*.72,s*.18);
  g.bezierCurveTo(s*.96,s*.3,s*.92,s*.58,s*.5,s*.88);
  g.closePath();
}
function drawHunter(g,s,skin,skinD,hair,tunic,tunicD){
  // club (behind body, in right hand)
  g.strokeStyle='#6b4423';g.lineWidth=s*.055;g.lineCap='round';
  g.beginPath();g.moveTo(s*.72,s*.6);g.lineTo(s*.88,s*.4);g.stroke();
  g.fillStyle=rg(g,s*.89,s*.37,s*.07,'#8a5a30','#5a3a1e');
  g.beginPath();g.ellipse(s*.89,s*.37,s*.075,s*.06,-.8,0,7);g.fill();
  // legs
  ell(g,s*.42,s*.85,s*.055,s*.09,skinD);
  ell(g,s*.58,s*.85,s*.055,s*.09,skinD);
  // tunic (fur)
  g.fillStyle=rg(g,s*.5,s*.62,s*.24,tunic,tunicD);
  g.beginPath();
  g.moveTo(s*.32,s*.48);
  g.quadraticCurveTo(s*.5,s*.42,s*.68,s*.48);
  g.lineTo(s*.72,s*.72);
  g.quadraticCurveTo(s*.5,s*.8,s*.28,s*.72);
  g.closePath();g.fill();
  // fur ticks
  g.strokeStyle=tunicD;g.lineWidth=s*.015;
  for(let i=0;i<4;i++){g.beginPath();g.moveTo(s*(.36+i*.09),s*.72);g.lineTo(s*(.34+i*.09),s*.78);g.stroke();}
  // arms
  ell(g,s*.28,s*.58,s*.05,s*.085,skin);
  ell(g,s*.72,s*.58,s*.05,s*.085,skin);
  // head
  g.fillStyle=rg(g,s*.5,s*.3,s*.19,skin,skinD);
  g.beginPath();g.arc(s*.5,s*.3,s*.185,0,7);g.fill();
  // hair cap
  g.fillStyle=hair;
  g.beginPath();g.arc(s*.5,s*.27,s*.19,Math.PI*1.02,Math.PI*1.98);
  g.quadraticCurveTo(s*.72,s*.34,s*.66,s*.2);
  g.closePath();g.fill();
  ell(g,s*.34,s*.3,s*.045,s*.07,hair);
  // eyes (facing right)
  g.fillStyle='#241a10';
  g.beginPath();g.arc(s*.55,s*.31,s*.022,0,7);g.fill();
  g.beginPath();g.arc(s*.64,s*.31,s*.022,0,7);g.fill();
  // brow
  g.strokeStyle=hair;g.lineWidth=s*.025;
  g.beginPath();g.moveTo(s*.51,s*.26);g.lineTo(s*.68,s*.26);g.stroke();
}
function outlined(c,col,px){
  col=col||'#17100a';px=px||3.5;
  const sil=document.createElement('canvas');sil.width=c.width;sil.height=c.height;
  const sg=sil.getContext('2d');
  sg.drawImage(c,0,0);
  sg.globalCompositeOperation='source-in';
  sg.fillStyle=col;sg.fillRect(0,0,c.width,c.height);
  const out=document.createElement('canvas');out.width=c.width;out.height=c.height;
  const og=out.getContext('2d');og.imageSmoothingEnabled=true;
  for(let a=0;a<8;a++){
    og.drawImage(sil,Math.cos(a*Math.PI/4)*px,Math.sin(a*Math.PI/4)*px);
  }
  og.drawImage(c,0,0);
  return out;
}
const SPR={};
SPR.caveman=mkS((g,s)=>drawHunter(g,s,'#d9a066','#b8834e','#4a3020','#8a5a30','#6b4423'));
SPR.caveman2=mkS((g,s)=>drawHunter(g,s,'#c98f5a','#a87546','#1c1410','#5a4a7a','#443860'));
SPR.grok=mkS((g,s)=>drawHunter(g,s,'#c99055','#a87646','#7a2f1d','#5a6e46','#465738'));
SPR.bat=mkS((g,s)=>{
  // wings
  g.fillStyle='#4a3a5c';
  g.beginPath();g.moveTo(s*.5,s*.5);
  g.quadraticCurveTo(s*.18,s*.28,s*.06,s*.5);
  g.quadraticCurveTo(s*.2,s*.5,s*.24,s*.6);
  g.quadraticCurveTo(s*.36,s*.52,s*.5,s*.58);g.closePath();g.fill();
  g.beginPath();g.moveTo(s*.5,s*.5);
  g.quadraticCurveTo(s*.82,s*.28,s*.94,s*.5);
  g.quadraticCurveTo(s*.8,s*.5,s*.76,s*.6);
  g.quadraticCurveTo(s*.64,s*.52,s*.5,s*.58);g.closePath();g.fill();
  // body
  g.fillStyle=rg(g,s*.5,s*.5,s*.16,'#7a6494','#584878');
  g.beginPath();g.ellipse(s*.5,s*.52,s*.13,s*.16,0,0,7);g.fill();
  // ears
  g.fillStyle='#584878';
  g.beginPath();g.moveTo(s*.42,s*.42);g.lineTo(s*.44,s*.3);g.lineTo(s*.5,s*.4);g.closePath();g.fill();
  g.beginPath();g.moveTo(s*.58,s*.42);g.lineTo(s*.56,s*.3);g.lineTo(s*.5,s*.4);g.closePath();g.fill();
  // eyes
  g.fillStyle='#ff5a4e';
  g.beginPath();g.arc(s*.45,s*.5,s*.025,0,7);g.fill();
  g.beginPath();g.arc(s*.55,s*.5,s*.025,0,7);g.fill();
});
SPR.bear=mkS((g,s)=>{
  // body
  g.fillStyle=rg(g,s*.45,s*.55,s*.36,'#7a5636','#4e3722');
  g.beginPath();g.ellipse(s*.45,s*.58,s*.36,s*.27,0,0,7);g.fill();
  // legs
  ell(g,s*.2,s*.82,s*.07,s*.08,'#3a2a1a');
  ell(g,s*.38,s*.84,s*.07,s*.08,'#3a2a1a');
  ell(g,s*.58,s*.84,s*.07,s*.08,'#3a2a1a');
  ell(g,s*.72,s*.82,s*.07,s*.08,'#3a2a1a');
  // head
  g.fillStyle=rg(g,s*.78,s*.42,s*.18,'#7a5636','#553c26');
  g.beginPath();g.arc(s*.78,s*.44,s*.17,0,7);g.fill();
  // ears
  ell(g,s*.68,s*.3,s*.05,s*.05,'#553c26');
  ell(g,s*.88,s*.3,s*.05,s*.05,'#553c26');
  // snout
  ell(g,s*.87,s*.5,s*.09,s*.065,'#a8815a');
  ell(g,s*.93,s*.48,s*.028,s*.022,'#241a10');
  // eye
  g.fillStyle='#ffdb70';
  g.beginPath();g.arc(s*.76,s*.4,s*.024,0,7);g.fill();
  g.fillStyle='#241a10';
  g.beginPath();g.arc(s*.77,s*.4,s*.012,0,7);g.fill();
  // claws
  g.strokeStyle='#e8e0d0';g.lineWidth=s*.014;
  for(const lx of [.16,.34]){g.beginPath();g.moveTo(s*lx,s*.88);g.lineTo(s*(lx-.02),s*.92);g.stroke();}
});
SPR.dino=mkS((g,s)=>{
  // tail
  g.fillStyle='#4e7530';
  g.beginPath();g.moveTo(s*.4,s*.58);
  g.quadraticCurveTo(s*.12,s*.5,s*.04,s*.62);
  g.quadraticCurveTo(s*.18,s*.62,s*.4,s*.7);g.closePath();g.fill();
  // body
  g.fillStyle=rg(g,s*.5,s*.6,s*.24,'#6d9c45','#4e7530');
  g.beginPath();g.ellipse(s*.5,s*.62,s*.22,s*.18,0,0,7);g.fill();
  // legs
  ell(g,s*.42,s*.84,s*.05,s*.07,'#40601f');
  ell(g,s*.6,s*.84,s*.05,s*.07,'#40601f');
  // neck+head
  g.fillStyle='#6d9c45';
  g.beginPath();g.moveTo(s*.62,s*.52);
  g.quadraticCurveTo(s*.7,s*.36,s*.78,s*.32);
  g.lineTo(s*.86,s*.36);
  g.quadraticCurveTo(s*.78,s*.48,s*.66,s*.6);g.closePath();g.fill();
  g.beginPath();g.ellipse(s*.82,s*.34,s*.1,s*.075,-.2,0,7);g.fill();
  // jaw
  g.fillStyle='#4e7530';
  g.beginPath();g.ellipse(s*.88,s*.39,s*.06,s*.03,-.2,0,7);g.fill();
  // eye
  g.fillStyle='#ffd94e';g.beginPath();g.arc(s*.8,s*.31,s*.024,0,7);g.fill();
  g.fillStyle='#241a10';g.beginPath();g.arc(s*.81,s*.31,s*.012,0,7);g.fill();
  // back spikes
  g.fillStyle='#3a5a22';
  for(let i=0;i<3;i++){
    const bx=s*(.36+i*.12);
    g.beginPath();g.moveTo(bx,s*.48);g.lineTo(bx+s*.05,s*.4);g.lineTo(bx+s*.1,s*.48);g.closePath();g.fill();
  }
});
SPR.serpent=mkS((g,s)=>{
  // coils
  g.fillStyle=rg(g,s*.5,s*.62,s*.3,'#5f8a4a','#3a5a3e');
  g.beginPath();g.ellipse(s*.5,s*.72,s*.32,s*.16,0,0,7);g.fill();
  g.beginPath();g.ellipse(s*.5,s*.55,s*.26,s*.14,0,0,7);g.fill();
  g.beginPath();g.ellipse(s*.5,s*.4,s*.19,s*.12,0,0,7);g.fill();
  // head
  g.fillStyle=rg(g,s*.5,s*.22,s*.15,'#6d9c5a','#3a5a3e');
  g.beginPath();g.ellipse(s*.5,s*.22,s*.16,s*.12,0,0,7);g.fill();
  // eyes
  g.fillStyle='#ffd94e';
  g.beginPath();g.arc(s*.43,s*.2,s*.03,0,7);g.fill();
  g.beginPath();g.arc(s*.57,s*.2,s*.03,0,7);g.fill();
  g.fillStyle='#241a10';
  g.fillRect(s*.425,s*.17,s*.012,s*.055);
  g.fillRect(s*.565,s*.17,s*.012,s*.055);
  // tongue
  g.strokeStyle='#c8402e';g.lineWidth=s*.018;
  g.beginPath();g.moveTo(s*.5,s*.32);g.lineTo(s*.5,s*.4);g.stroke();
  g.beginPath();g.moveTo(s*.5,s*.4);g.lineTo(s*.46,s*.45);g.moveTo(s*.5,s*.4);g.lineTo(s*.54,s*.45);g.stroke();
  // scale sheen
  g.strokeStyle='rgba(255,255,255,.12)';g.lineWidth=s*.02;
  g.beginPath();g.arc(s*.44,s*.55,s*.16,3.6,4.6);g.stroke();
});
SPR.meat=mkS((g,s)=>{
  g.strokeStyle='#e8d9c0';g.lineWidth=s*.09;g.lineCap='round';
  g.beginPath();g.moveTo(s*.62,s*.62);g.lineTo(s*.8,s*.8);g.stroke();
  ell(g,s*.84,s*.84,s*.06,s*.06,'#e8d9c0');
  g.fillStyle=rg(g,s*.42,s*.42,s*.3,'#d9705a','#a33d2b');
  g.beginPath();g.ellipse(s*.44,s*.44,s*.3,s*.24,-.7,0,7);g.fill();
  g.fillStyle='rgba(255,255,255,.18)';
  g.beginPath();g.ellipse(s*.36,s*.36,s*.12,s*.08,-.7,0,7);g.fill();
});
SPR.heart=mkS((g,s)=>{
  heartPath(g,s);
  g.fillStyle=rg(g,s*.5,s*.4,s*.45,'#f06a55','#b02a1e');g.fill();
  g.fillStyle='rgba(255,255,255,.25)';
  g.beginPath();g.ellipse(s*.34,s*.32,s*.09,s*.06,-.5,0,7);g.fill();
});
SPR.heartHalf=mkS((g,s)=>{
  g.save();g.beginPath();g.rect(0,0,s*.5,s);g.clip();
  heartPath(g,s);
  g.fillStyle=rg(g,s*.5,s*.4,s*.45,'#f06a55','#b02a1e');g.fill();
  g.restore();
  heartPath(g,s);
  g.strokeStyle='#4a3020';g.lineWidth=s*.05;g.stroke();
});
SPR.heartEmpty=mkS((g,s)=>{
  heartPath(g,s);
  g.strokeStyle='#4a3020';g.lineWidth=s*.05;g.stroke();
});
SPR.flint=mkS((g,s)=>{
  g.fillStyle=rg(g,s*.5,s*.5,s*.35,'#b9c6cf','#75828c');
  g.beginPath();g.moveTo(s*.24,s*.8);g.lineTo(s*.42,s*.28);g.lineTo(s*.6,s*.2);g.lineTo(s*.74,s*.44);g.lineTo(s*.56,s*.78);g.closePath();g.fill();
  g.strokeStyle='rgba(0,0,0,.25)';g.lineWidth=s*.02;
  g.beginPath();g.moveTo(s*.42,s*.3);g.lineTo(s*.5,s*.72);g.moveTo(s*.6,s*.24);g.lineTo(s*.52,s*.5);g.stroke();
});
SPR.stone=mkS((g,s)=>{
  g.fillStyle=rg(g,s*.5,s*.5,s*.3,'#a39a8e','#6e675e');
  g.beginPath();g.ellipse(s*.5,s*.52,s*.28,s*.25,0,0,7);g.fill();
  g.fillStyle='rgba(255,255,255,.2)';
  g.beginPath();g.ellipse(s*.42,s*.42,s*.09,s*.06,0,0,7);g.fill();
});
SPR.rock=mkS((g,s)=>{
  g.fillStyle=rg(g,s*.48,s*.5,s*.42,'#6b5c4d','#3f352b');
  g.beginPath();
  g.moveTo(s*.14,s*.72);g.quadraticCurveTo(s*.1,s*.42,s*.32,s*.3);
  g.quadraticCurveTo(s*.52,s*.16,s*.72,s*.3);
  g.quadraticCurveTo(s*.92,s*.44,s*.86,s*.7);
  g.quadraticCurveTo(s*.5,s*.86,s*.14,s*.72);g.closePath();g.fill();
  g.fillStyle='rgba(255,255,255,.12)';
  g.beginPath();g.ellipse(s*.36,s*.36,s*.13,s*.08,-.4,0,7);g.fill();
  g.strokeStyle='rgba(0,0,0,.25)';g.lineWidth=s*.02;
  g.beginPath();g.moveTo(s*.5,s*.4);g.lineTo(s*.6,s*.62);g.stroke();
});
SPR.obrock=mkS((g,s)=>{
  g.fillStyle=rg(g,s*.48,s*.5,s*.42,'#3a2f52','#14101e');
  g.beginPath();
  g.moveTo(s*.14,s*.72);g.quadraticCurveTo(s*.1,s*.42,s*.32,s*.3);
  g.quadraticCurveTo(s*.52,s*.16,s*.72,s*.3);
  g.quadraticCurveTo(s*.92,s*.44,s*.86,s*.7);
  g.quadraticCurveTo(s*.5,s*.86,s*.14,s*.72);g.closePath();g.fill();
  g.strokeStyle='rgba(140,110,220,.4)';g.lineWidth=s*.025;
  g.beginPath();g.moveTo(s*.3,s*.4);g.lineTo(s*.46,s*.66);g.moveTo(s*.6,s*.3);g.lineTo(s*.7,s*.55);g.stroke();
  g.fillStyle='rgba(160,130,240,.2)';
  g.beginPath();g.ellipse(s*.38,s*.36,s*.11,s*.07,-.4,0,7);g.fill();
});
SPR.root=mkS((g,s)=>{
  g.strokeStyle='#8a8070';g.lineWidth=s*.14;g.lineCap='round';
  g.beginPath();g.moveTo(s*.5,s*.85);
  g.quadraticCurveTo(s*.42,s*.55,s*.52,s*.3);g.stroke();
  g.fillStyle=rg(g,s*.52,s*.26,s*.18,'#c2b79c','#8a8070');
  g.beginPath();g.ellipse(s*.52,s*.26,s*.19,s*.13,0,0,7);g.fill();
  g.fillStyle='rgba(255,255,255,.15)';
  g.beginPath();g.ellipse(s*.46,s*.22,s*.07,s*.04,0,0,7);g.fill();
});
SPR.torch=mkS((g,s)=>{
  g.strokeStyle='#6b4423';g.lineWidth=s*.1;g.lineCap='round';
  g.beginPath();g.moveTo(s*.5,s*.9);g.lineTo(s*.5,s*.5);g.stroke();
  const fg=g.createRadialGradient(s*.5,s*.32,s*.03,s*.5,s*.36,s*.26);
  fg.addColorStop(0,'#ffe9a8');fg.addColorStop(.45,'#ffb545');fg.addColorStop(1,'rgba(255,110,30,0)');
  g.fillStyle=fg;
  g.beginPath();g.moveTo(s*.5,s*.08);
  g.quadraticCurveTo(s*.7,s*.32,s*.5,s*.52);
  g.quadraticCurveTo(s*.3,s*.32,s*.5,s*.08);g.closePath();g.fill();
});
SPR.bone=mkS((g,s)=>{
  g.strokeStyle='#cfc2a8';g.lineWidth=s*.11;g.lineCap='round';
  g.beginPath();g.moveTo(s*.3,s*.7);g.lineTo(s*.7,s*.3);g.stroke();
  for(const [bx,by] of [[.26,.62],[.36,.76],[.64,.24],[.76,.36]]){
    ell(g,s*bx,s*by,s*.075,s*.075,'#e0d5bc');
  }
});
SPR.slab=mkS((g,s)=>{
  g.fillStyle=rg(g,s*.5,s*.5,s*.45,'#55483c','#2e2620');
  g.beginPath();
  if(g.roundRect)g.roundRect(s*.12,s*.12,s*.76,s*.76,s*.12);
  else g.rect(s*.12,s*.12,s*.76,s*.76);
  g.fill();
  g.strokeStyle='rgba(0,0,0,.3)';g.lineWidth=s*.025;
  g.beginPath();g.moveTo(s*.3,s*.3);g.lineTo(s*.7,s*.3);g.moveTo(s*.3,s*.5);g.lineTo(s*.66,s*.5);g.moveTo(s*.34,s*.7);g.lineTo(s*.7,s*.7);g.stroke();
});
SPR.wood=mkS((g,s)=>{
  g.strokeStyle='#8a5a30';g.lineWidth=s*.16;g.lineCap='round';
  g.beginPath();g.moveTo(s*.26,s*.76);g.lineTo(s*.74,s*.26);g.stroke();
  g.strokeStyle='#6b4423';g.lineWidth=s*.03;
  g.beginPath();g.moveTo(s*.34,s*.66);g.lineTo(s*.62,s*.36);g.stroke();
});
SPR.sinew=mkS((g,s)=>{
  g.strokeStyle='#c9a06a';g.lineWidth=s*.07;
  g.beginPath();g.arc(s*.5,s*.5,s*.24,0,5.6);g.stroke();
  g.beginPath();g.arc(s*.5,s*.5,s*.13,.8,6.2);g.stroke();
});
SPR.feather=mkS((g,s)=>{
  g.fillStyle=rg(g,s*.5,s*.45,s*.35,'#d5e2ee','#8aa2ba');
  g.beginPath();g.moveTo(s*.3,s*.82);
  g.quadraticCurveTo(s*.24,s*.4,s*.62,s*.16);
  g.quadraticCurveTo(s*.74,s*.44,s*.42,s*.76);g.closePath();g.fill();
  g.strokeStyle='#6a82a0';g.lineWidth=s*.025;
  g.beginPath();g.moveTo(s*.32,s*.8);g.quadraticCurveTo(s*.44,s*.5,s*.6,s*.2);g.stroke();
});
SPR.fang=mkS((g,s)=>{
  g.fillStyle=rg(g,s*.5,s*.4,s*.3,'#fffaf0','#cfc2a8');
  g.beginPath();g.moveTo(s*.36,s*.22);
  g.quadraticCurveTo(s*.66,s*.26,s*.62,s*.5);
  g.quadraticCurveTo(s*.58,s*.72,s*.44,s*.82);
  g.quadraticCurveTo(s*.4,s*.55,s*.36,s*.22);g.closePath();g.fill();
});
SPR.obsidian=mkS((g,s)=>{
  g.fillStyle=rg(g,s*.5,s*.5,s*.32,'#4a3d6e','#120e1c');
  g.beginPath();g.moveTo(s*.3,s*.74);g.lineTo(s*.44,s*.26);g.lineTo(s*.64,s*.2);g.lineTo(s*.7,s*.5);g.lineTo(s*.52,s*.8);g.closePath();g.fill();
  g.strokeStyle='rgba(150,120,230,.55)';g.lineWidth=s*.022;
  g.beginPath();g.moveTo(s*.44,s*.28);g.lineTo(s*.54,s*.7);g.stroke();
});
SPR.shrine=mkS((g,s)=>{
  g.fillStyle=rg(g,s*.5,s*.5,s*.4,'#5c5044','#332b23');
  g.beginPath();
  g.moveTo(s*.32,s*.9);g.lineTo(s*.34,s*.24);
  g.quadraticCurveTo(s*.5,s*.08,s*.66,s*.24);
  g.lineTo(s*.68,s*.9);g.closePath();g.fill();
  // ochre spiral
  g.strokeStyle='#c1642a';g.lineWidth=s*.035;
  g.beginPath();
  for(let a=0;a<14;a++){
    const r=s*.02+a*s*.012,ang=a*.65;
    const px=s*.5+Math.cos(ang)*r,py=s*.5+Math.sin(ang)*r;
    if(a===0)g.moveTo(px,py);else g.lineTo(px,py);
  }
  g.stroke();
});
SPR.bola=mkS((g,s)=>{
  g.strokeStyle='#c9a06a';g.lineWidth=s*.05;
  g.beginPath();g.moveTo(s*.3,s*.32);g.quadraticCurveTo(s*.5,s*.5,s*.7,s*.32);g.stroke();
  ell(g,s*.28,s*.3,s*.11,s*.11,'#8a8176');
  ell(g,s*.72,s*.3,s*.11,s*.11,'#8a8176');
  g.fillStyle='rgba(255,255,255,.2)';
  ell(g,s*.25,s*.26,s*.035,s*.025,'rgba(255,255,255,.25)');
});
// cel-style dark outlines: characters pop against every background,
// pickups get a warm outline so saturation stays reserved for loot
for(const k of ['caveman','caveman2','grok','bat','bear','dino','serpent'])SPR[k]=outlined(SPR[k],'#17100a',4);
for(const k of ['meat','heart','flint','stone','rock','obrock','root','bone','slab','wood','sinew','feather','fang','obsidian','shrine','bola'])SPR[k]=outlined(SPR[k],'#1c130c',3);

// ---------- constants ----------
const C=17,R=11;
const DOOR={n:{ti:8,tj:0},s:{ti:8,tj:R-1},w:{ti:0,tj:5},e:{ti:C-1,tj:5}};
const OPP={n:'s',s:'n',w:'e',e:'w'};
const DIRV={n:[0,-1],s:[0,1],w:[-1,0],e:[1,0]};
const O_NONE=0,O_ROCK=1,O_WATER=2,O_BONES=3,O_ROOT=4,O_OBROCK=5;
const MATS=['flint','wood','bone','sinew','feather','fang','obsidian'];
const REC=[
 {id:'spear', kind:'passive',name:'FLINT SPEAR',   cost:{flint:1,wood:1},              fx:'+1 DMG · STONES PIERCE',    lore:'knapped edge, hafted with sinew. it drinks deep.'},
 {id:'atlatl',kind:'passive',name:'ATLATL',        cost:{wood:1,sinew:1},              fx:'STONES FLY FAR AND FAST',   lore:'the arm-lengthener. secret of the old hunters.'},
 {id:'edge',  kind:'passive',name:'OBSIDIAN EDGE', cost:{obsidian:1,flint:1},          fx:'+2 DMG',                    lore:'black glass from the deep. it remembers being fire.'},
 {id:'totem', kind:'passive',name:'BONE TOTEM',    cost:{bone:1,fang:1},               fx:'+1 HEART (ALL)',            lore:'urm says nothing. the totem hums anyway.'},
 {id:'fletch',kind:'passive',name:'FEATHER FLETCH',cost:{feather:1,wood:1},            fx:'THROW MUCH FASTER',         lore:"bat-feather guides the stone's dreaming."},
 {id:'bola',  kind:'active', name:'BOLA',          cost:{bone:1,sinew:1},              fx:'TOOL · SNARES BEASTS',      lore:'two stones, one cord. the legs stop first.'},
 {id:'dart',  kind:'active', name:'OBSIDIAN DART', cost:{obsidian:1,wood:1,feather:1}, fx:'TOOL · PIERCING SNIPE',     lore:'a sliver of night on a straight-grained shaft.'},
 {id:'fist',  kind:'active', name:"URM'S FIST",    cost:{obsidian:1,bone:1,sinew:1},   fx:'TOOL · GROUND SLAM',        lore:"the mountain's own knuckle, borrowed briefly."},
];
const ACD_MAX={bola:4,dart:5,fist:7};
const DEPTH_LORE=['THE CAVE SWALLOWS YOU','OLD BONES. OLDER WALLS.','BLACK GLASS GROWS HERE','THE PAINTINGS WATCH BACK','SLITHER-MARKS IN THE DUST','YOU HEAR THE TOWER BREATHE','ROOTS OF THE FIRST TOWER'];
const TOWER_LORE=['GHUR, FIRST OF BEARS, BARS THE WAY','A SLITHER-PRIEST HISSES YOUR NAME','THE TOWER REMEMBERS BEING WORSHIPPED'];
const GROK_LINES=['"GROK GIVE MEAT. FRIEND STRONG."','"GROK SEE SLITHER-MEN BELOW. GROK NO GO."','"BLACK STONE CUT DEEP. GROK KNOW."','"TOWER OLD. OLDER THAN URM? GROK NOT SAY."'];

// ---------- settings ----------
let aimMode='auto'; // 'auto' | 'twin'
let difficulty='hunter';
let soundOn=true;
const DIFF={cub:{hp:.7,dmg:.66,hunger:.6},hunter:{hp:1,dmg:1,hunger:1},chosen:{hp:1.4,dmg:1.5,hunger:1.3}};
function setDiff(d){difficulty=d;
  document.getElementById('diffcub').classList.toggle('sel',d==='cub');
  document.getElementById('diffhunter').classList.toggle('sel',d==='hunter');
  document.getElementById('diffchosen').classList.toggle('sel',d==='chosen');}
document.getElementById('diffcub').addEventListener('click',()=>setDiff('cub'));
document.getElementById('diffhunter').addEventListener('click',()=>setDiff('hunter'));
document.getElementById('diffchosen').addEventListener('click',()=>setDiff('chosen'));
document.getElementById('sndbtn').addEventListener('click',()=>{
  soundOn=!soundOn;
  const b=document.getElementById('sndbtn');
  b.textContent=soundOn?'SOUND ON':'SOUND OFF';
  b.classList.toggle('sel',soundOn);
});
const btnAuto=document.getElementById('aimauto');
const btnTwin=document.getElementById('aimtwin');
function setAim(m){aimMode=m;btnAuto.classList.toggle('sel',m==='auto');btnTwin.classList.toggle('sel',m==='twin');}
btnAuto.addEventListener('click',()=>setAim('auto'));
btnTwin.addEventListener('click',()=>setAim('twin'));

// ---------- input: keyboard/mouse ----------
const keys={};
let mouse={x:0,y:0,down:false};
window.addEventListener('keydown',e=>{keys[e.code]=true;
  if(['Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.code))e.preventDefault();
  if(e.code==='KeyR'&&game&&game.dead)start(game.twoP?2:1);
  if(e.code==='KeyC'&&game&&!game.dead&&!game.trans&&!game.paused)game.craftOpen=!game.craftOpen;
  if((e.code==='Escape'||e.code==='KeyP')&&game&&!game.dead){
    if(game.craftOpen)game.craftOpen=false;
    else setPause(!game.paused);
  }
  if(game&&game.craftOpen&&/^Digit[1-8]$/.test(e.code))craft(parseInt(e.code[5])-1);
});
window.addEventListener('keyup',e=>{keys[e.code]=false;});
cvs.addEventListener('mousemove',e=>{const r=cvs.getBoundingClientRect();mouse.x=e.clientX-r.left;mouse.y=e.clientY-r.top;});
cvs.addEventListener('mousedown',e=>{
  mouse.down=true;
  if(game&&game.craftOpen)craftPanelTap(e.clientX,e.clientY);
});
window.addEventListener('mouseup',()=>{mouse.down=false;});
window.addEventListener('contextmenu',e=>e.preventDefault());

// ---------- input: touch ----------
const touch={
  moveId:null,moveOx:0,moveOy:0,moveDx:0,moveDy:0,
  aimId:null,aimOx:0,aimOy:0,aimDx:0,aimDy:0,
  firing:false,btns:{},panelRows:[],
};
function touchXY(t){const r=cvs.getBoundingClientRect();return{x:t.clientX-r.left,y:t.clientY-r.top};}
function hitBtn(x,y){
  for(const id in touch.btns){
    const b=touch.btns[id];
    if(Math.hypot(x-b.x,y-b.y)<b.r+8)return id;
  }
  return null;
}
cvs.addEventListener('touchstart',e=>{
  e.preventDefault();
  if(!game||game.dead)return;
  for(const t of e.changedTouches){
    const p=touchXY(t);
    if(game.craftOpen){
      // tap craft rows / close btn
      craftPanelTap(t.clientX,t.clientY);
      continue;
    }
    const b=hitBtn(p.x,p.y);
    if(b){
      if(b==='throw'){touch.firing=true;touch.btns.throw.tid=t.identifier;}
      else if(b==='tool0')useActive(0,game.players[0]);
      else if(b==='tool1')useActive(1,game.players[0]);
      else if(b==='craft')game.craftOpen=true;
      else if(b==='pause')setPause(true);
      continue;
    }
    if(p.x<VW*.45&&touch.moveId===null){
      touch.moveId=t.identifier;touch.moveOx=p.x;touch.moveOy=p.y;touch.moveDx=0;touch.moveDy=0;
    } else if(p.x>=VW*.45&&aimMode==='twin'&&touch.aimId===null){
      touch.aimId=t.identifier;touch.aimOx=p.x;touch.aimOy=p.y;touch.aimDx=0;touch.aimDy=0;
    }
  }
},{passive:false});
cvs.addEventListener('touchmove',e=>{
  e.preventDefault();
  for(const t of e.changedTouches){
    const p=touchXY(t);
    if(t.identifier===touch.moveId){
      touch.moveDx=p.x-touch.moveOx;touch.moveDy=p.y-touch.moveOy;
      const m=Math.hypot(touch.moveDx,touch.moveDy),max=52;
      if(m>max){touch.moveDx*=max/m;touch.moveDy*=max/m;}
    } else if(t.identifier===touch.aimId){
      touch.aimDx=p.x-touch.aimOx;touch.aimDy=p.y-touch.aimOy;
      const m=Math.hypot(touch.aimDx,touch.aimDy),max=52;
      if(m>max){touch.aimDx*=max/m;touch.aimDy*=max/m;}
    }
  }
},{passive:false});
function touchEnd(e){
  for(const t of e.changedTouches){
    if(t.identifier===touch.moveId){touch.moveId=null;touch.moveDx=0;touch.moveDy=0;}
    if(t.identifier===touch.aimId){touch.aimId=null;touch.aimDx=0;touch.aimDy=0;}
    if(touch.btns.throw&&touch.btns.throw.tid===t.identifier){touch.firing=false;touch.btns.throw.tid=null;}
  }
}
cvs.addEventListener('touchend',touchEnd);
cvs.addEventListener('touchcancel',touchEnd);

// ---------- layout ----------
let TILE=56,ORX=0,ORY=0,HUDH=64;
function computeLayout(lockTile){
  if(!lockTile)TILE=Math.floor(Math.min((VW-16)/C,(VH-HUDH-(IS_TOUCH?36:24))/R));
  ORX=(VW-C*TILE)/2|0;
  ORY=HUDH+((VH-HUDH-R*TILE)/2|0);
}

// ---------- utils ----------
function hash(i,j,s){let n=i*374761393+j*668265263+s*974634311;n=(n^(n>>13))*1274126177;return((n^(n>>16))>>>0)/4294967295;}
function key(x,y){return x+','+y;}
let game=null,shake=0,msgTimer=0;
function showMsg(t){const m=document.getElementById('msg');m.textContent=t;m.style.opacity=1;msgTimer=2.8;}

// ---------- floor generation ----------
function genFloor(depth){
  const rooms={};
  const add=(x,y)=>{rooms[key(x,y)]={gx:x,gy:y,type:'normal',visited:false,cleared:false,spawned:false,
    seed:(Math.random()*1e9)|0,obst:null,live:[],items:[],grok:null,shrine:null,slabT:0,tileHP:{},drops:[]};};
  add(0,0);
  const target=6+depth+Math.min(depth,4);
  let guard=0;
  while(Object.keys(rooms).length<target&&guard++<600){
    const ks=Object.keys(rooms);
    const r=rooms[ks[Math.random()*ks.length|0]];
    const dirs=['n','s','w','e'];
    const d=dirs[Math.random()*4|0];
    const nx=r.gx+DIRV[d][0],ny=r.gy+DIRV[d][1];
    if(rooms[key(nx,ny)])continue;
    let touchN=0;
    for(const dd of dirs){const tx=nx+DIRV[dd][0],ty=ny+DIRV[dd][1];if(rooms[key(tx,ty)])touchN++;}
    if(touchN>1)continue;
    add(nx,ny);
  }
  const list=Object.values(rooms);
  for(const r of list){
    r.doors={};
    for(const d of ['n','s','w','e']){
      const n=rooms[key(r.gx+DIRV[d][0],r.gy+DIRV[d][1])];
      if(n)r.doors[d]=true;
    }
  }
  const deadEnds=list.filter(r=>Object.keys(r.doors).length===1&&!(r.gx===0&&r.gy===0));
  deadEnds.sort((a,b)=>(Math.abs(b.gx)+Math.abs(b.gy))-(Math.abs(a.gx)+Math.abs(a.gy)));
  if(deadEnds[0])deadEnds[0].type='exit';
  if(deadEnds[1])deadEnds[1].type='treasure';
  if(deadEnds[2])deadEnds[2].type='grok';
  for(const r of list){
    if(r.type==='normal'&&!(r.gx===0&&r.gy===0)){
      const rr=Math.random();
      if(rr<.1)r.type='shrine';
      else if(rr<.3)r.type='water';
      else if(rr<.42&&depth>=2)r.type='dino';
    }
  }
  const startR=rooms[key(0,0)];
  startR.type='start';startR.cleared=true;startR.spawned=true;startR.visited=true;
  return rooms;
}

// ---------- room content ----------
function buildRoom(room,depth){
  if(room.obst)return;
  const g=(i,j)=>hash(i,j,room.seed);
  const obst=Array.from({length:R},()=>Array(C).fill(O_NONE));
  const laneX=DOOR.n.ti,laneY=DOOR.w.tj;
  if(room.type==='tower'){
    for(const [pi,pj] of [[4,3],[12,3],[4,7],[12,7]])obst[pj][pi]=O_ROCK;
  } else {
    for(let j=2;j<R-2;j++)for(let i=2;i<=C>>1;i++){
      const nearLane=(Math.abs(i-laneX)<=1)||(Math.abs(j-laneY)<=1);
      const center=(Math.abs(i-8)<=2&&Math.abs(j-5)<=1);
      if(nearLane||center)continue;
      const v=g(i,j);
      let cell=O_NONE;
      if(room.type==='water'){if(v<.18)cell=O_WATER;else if(v<.26)cell=O_ROCK;}
      else if(room.type==='dino'){if(v<.16)cell=O_ROCK;}
      else if(['treasure','grok','start','shrine'].includes(room.type)){if(v<.06)cell=O_BONES;}
      else{if(v<.1)cell=O_ROCK;else if(v<.14)cell=(depth>=3&&v<.12)?O_OBROCK:O_ROCK;else if(v<.18)cell=O_ROOT;else if(v<.21)cell=O_BONES;else if(v<.24&&depth>=2)cell=O_WATER;}
      obst[j][i]=cell;obst[j][C-1-i]=cell;
    }
    if(room.type==='water'){
      for(let j=4;j<=6;j++)for(let i=6;i<=10;i++)if(!(j===5&&Math.abs(i-8)<=1))obst[j][i]=O_WATER;
    }
  }
  room.obst=obst;
  room.tileHP={};
  room.drops=room.drops||[];
  for(let j=0;j<R;j++)for(let i=0;i<C;i++){
    if(obst[j][i]===O_ROCK)room.tileHP[i+','+j]=3;
    else if(obst[j][i]===O_ROOT)room.tileHP[i+','+j]=2;
    else if(obst[j][i]===O_OBROCK)room.tileHP[i+','+j]=4;
  }
  if(room.type==='shrine')room.shrine={ti:8,tj:5,used:false};
  if(room.type==='treasure')room.items.push({type:(depth%2?'flint_item':'heart'),ti:8,tj:5,bob:0,pedestal:true});
  if(room.type==='grok')room.grok={ti:8,tj:5,gave:false,t:Math.random()*10};
}
function spawnEnemies(room,depth,entryDir){
  room.spawned=true;
  const defs=[];
  function pick(pool,n){const out=[];for(let i=0;i<n;i++)out.push(pool[Math.random()*pool.length|0]);return out;}
  const mult=game&&game.twoP?1:0;
  if(room.type==='normal')defs.push(...pick(['bat','bat','bear'],2+Math.min(depth,3)+mult));
  else if(room.type==='water'){defs.push('bat','bat');if(depth>=2)defs.push('dino');if(mult)defs.push('bat');}
  else if(room.type==='dino'){defs.push('dino','dino');if(depth>=3)defs.push('bat');if(mult)defs.push('dino');}
  else if(room.type==='exit'){defs.push('bear');if(depth>=2)defs.push('bear');if(depth>=4)defs.push('dino');if(mult)defs.push('bat');}
  else if(room.type==='treasure'&&depth>=3)defs.push('bat');
  const ed=DOOR[OPP[entryDir]||'s'];
  const cells=[];
  for(let j=1;j<R-1;j++)for(let i=1;i<C-1;i++){
    const c=room.obst[j][i];
    if(c===O_ROCK||c===O_ROOT||c===O_OBROCK)continue;
    if(Math.hypot(i-ed.ti,j-ed.tj)<4.5)continue;
    if(Math.hypot(i-8,j-5)<2&&room.type==='exit')continue;
    cells.push([i,j]);
  }
  for(const d of defs){
    if(!cells.length)break;
    const [i,j]=cells.splice(Math.random()*cells.length|0,1)[0];
    room.live.push(newEnemy(d,(i+.5)*TILE,(j+.5)*TILE,depth));
  }
}
function newEnemy(type,x,y,depth){
  const B={
    bat:{hp:2,spd:TILE*2.3,dmg:1,r:TILE*.24,fly:true,spr:SPR.bat,f:.85},
    bear:{hp:6+depth,spd:TILE*1.25,dmg:2,r:TILE*.42,fly:false,spr:SPR.bear,f:1.3},
    dino:{hp:3+((depth/2)|0),spd:TILE*1.1,dmg:1,r:TILE*.3,fly:false,spr:SPR.dino,f:1.05},
  }[type];
  const D=DIFF[difficulty];
  const hp2=Math.max(1,Math.round(B.hp*D.hp));
  const dmg2=Math.max(1,Math.round(B.dmg*D.dmg));
  return{type,x,y,hp:hp2,maxhp:hp2,spd:B.spd,dmg:dmg2,r:B.r,fly:B.fly,spr:B.spr,sc:TILE*B.f/S,
    ranged:type==='dino',vx:0,vy:0,t:Math.random()*10,hitFlash:0,wanderA:Math.random()*6.3,wanderT:0,spitCd:1+Math.random(),slow:0};
}
function newBoss(tier){
  const serpent=tier>=2;
  const D=DIFF[difficulty];
  const bhp=Math.max(8,Math.round((22+12*tier)*D.hp));
  return{boss:true,type:'boss',
    name:serpent?'SLITHER-PRIEST OF THE TOWER':'GHUR, FIRST OF BEARS',
    x:8.5*TILE,y:3.2*TILE,
    hp:bhp,maxhp:bhp,
    spd:TILE*(serpent?1.0:0.9),dmg:2,r:TILE*.6,fly:false,
    spr:serpent?SPR.serpent:SPR.bear,sc:TILE*(serpent?2.2:2.5)/S,
    ranged:false,vx:0,vy:0,t:0,hitFlash:0,wanderA:0,wanderT:0,spitCd:2.5,slow:0,
    state:'chase',atkT:3,wind:0,charge:0,cdx:0,cdy:0,summoned:false,serpent,tier};
}

// ---------- game start ----------
function mkPlayer(id){
  return{id,x:8.5*TILE,y:5.5*TILE,hp:6,maxhp:6,r:TILE*.27,
    cd:0,cdMax:.38,dmg:1,hurtCd:0,face:1,walk:0,down:false,fdx:1,fdy:0};
}
function start(np){
  computeLayout(false);
  game={
    twoP:np===2,mode:'cave',depth:1,towerTier:0,kills:0,dead:false,
    players:[],hunger:100,starveT:0,
    rooms:null,cur:null,
    stones:[],spits:[],bolas:[],parts:[],floats:[],
    trans:null,time:0,clearFlash:0,
    mats:{flint:0,wood:0,bone:0,sinew:0,feather:0,fang:0,obsidian:0},
    crafted:{},actives:[],acd:{bola:0,dart:0,fist:0},
    pierce:0,projMul:1,craftOpen:false,
  };
  game.players.push(mkPlayer(0));
  if(game.twoP)game.players.push(mkPlayer(1));
  newCaveFloor();
  document.getElementById('overlay').classList.add('hidden');
  document.getElementById('death').classList.add('hidden');
  document.getElementById('pause').classList.add('hidden');
  document.getElementById('controls').textContent=IS_TOUCH?
    'LEFT THUMB: MOVE · '+(aimMode==='twin'?'RIGHT THUMB: AIM & FIRE':'HOLD ⦿ TO THROW (AUTO-AIM)')+' · TAP TOOLS & CRAFT':
    (game.twoP?
    'P1: WASD·MOUSE·SPACE·Q/E   P2: ARROWS·ENTER·RSHIFT/RCTRL   [C] CRAFT · SHARED POUCH':
    'WASD MOVE · MOUSE AIM · CLICK/SPACE THROW · Q/E TOOLS · [C] CRAFT · BREAK ROCKS FOR LOOT');
}
function placePlayers(x,y){
  game.players.forEach((p,i)=>{
    p.x=x+(i?TILE*.5:game.twoP?-TILE*.5:0);p.y=y;
  });
}
function revivePlayers(){
  for(const p of game.players){
    if(p.down){p.down=false;p.hp=2;floatText(p.x,p.y-TILE*.6,'URM GIVES ANOTHER STONE','#c1642a');}
  }
}
function newCaveFloor(){
  game.mode='cave';
  game.rooms=genFloor(game.depth);
  game.cur=game.rooms[key(0,0)];
  buildRoom(game.cur,game.depth);
  placePlayers(8.5*TILE,5.5*TILE);
  revivePlayers();
  game.stones.length=0;game.spits.length=0;game.bolas.length=0;
  showMsg(DEPTH_LORE[Math.min(game.depth-1,DEPTH_LORE.length-1)]+(game.depth>1?'  ·  CAVE '+game.depth:''));
}
function newTowerFloor(){
  game.mode='tower';
  const room={gx:0,gy:0,type:'tower',visited:true,cleared:false,spawned:true,
    seed:(Math.random()*1e9)|0,obst:null,live:[],items:[],grok:null,shrine:null,slabT:0,tileHP:{},drops:[],doors:{}};
  game.rooms={'0,0':room};
  game.cur=room;
  buildRoom(room,game.depth);
  room.live.push(newBoss(game.towerTier));
  placePlayers(8.5*TILE,8.6*TILE);
  revivePlayers();
  game.stones.length=0;game.spits.length=0;game.bolas.length=0;
  sfx('boss');shake=8;
  showMsg(TOWER_LORE[Math.min(game.towerTier-1,TOWER_LORE.length-1)]);
}
document.getElementById('startbtn').addEventListener('click',()=>{audio();start(1);});
document.getElementById('start2btn').addEventListener('click',()=>{audio();start(2);});

// ---------- solidity ----------
function isDoorTile(ti,tj){for(const d in DOOR){if(DOOR[d].ti===ti&&DOOR[d].tj===tj)return d;}return null;}
function roomDoorsOpen(room){return room.cleared||(room.spawned&&room.live.length===0);}
function solidAt(room,px,py,fly){
  const ti=px/TILE|0,tj=py/TILE|0;
  if(ti<0||tj<0||ti>=C||tj>=R)return true;
  if(ti===0||tj===0||ti===C-1||tj===R-1){
    const d=isDoorTile(ti,tj);
    if(d&&room.doors[d]&&roomDoorsOpen(room))return false;
    return true;
  }
  if(!fly&&room.obst){const c=room.obst[tj][ti];if(c===O_ROCK||c===O_ROOT||c===O_OBROCK)return true;}
  return false;
}
function moveCircle(room,o,dx,dy,fly){
  let nx=o.x+dx;
  const r=o.r;
  if(!solidAt(room,nx-r,o.y-r*.6,fly)&&!solidAt(room,nx+r,o.y-r*.6,fly)&&!solidAt(room,nx-r,o.y+r*.6,fly)&&!solidAt(room,nx+r,o.y+r*.6,fly))o.x=nx;
  let ny=o.y+dy;
  if(!solidAt(room,o.x-r*.6,ny-r,fly)&&!solidAt(room,o.x+r*.6,ny-r,fly)&&!solidAt(room,o.x-r*.6,ny+r,fly)&&!solidAt(room,o.x+r*.6,ny+r,fly))o.y=ny;
}
function cellAtPx(room,px,py){
  const ti=px/TILE|0,tj=py/TILE|0;
  if(ti<1||tj<1||ti>=C-1||tj>=R-1)return O_NONE;
  return room.obst?room.obst[tj][ti]:O_NONE;
}
function keepInRoom(o){
  // hard clamp inside interior; if stuck in a solid tile, nudge toward room center
  const minX=TILE+o.r*.4,maxX=(C-1)*TILE-o.r*.4;
  const minY=TILE+o.r*.4,maxY=(R-1)*TILE-o.r*.4;
  if(o.x<minX)o.x=minX;if(o.x>maxX)o.x=maxX;
  if(o.y<minY)o.y=minY;if(o.y>maxY)o.y=maxY;
  let guard=0;
  const cx=8.5*TILE,cy=5.5*TILE;
  while(guard++<40&&solidAt(game.cur,o.x,o.y,o.fly)){
    const d=Math.hypot(cx-o.x,cy-o.y)||1;
    o.x+=(cx-o.x)/d*3;o.y+=(cy-o.y)/d*3;
  }
}
function alivePlayers(){return game.players.filter(p=>!p.down);}
function nearestPlayer(x,y){
  let best=null,bd=1e9;
  for(const p of alivePlayers()){
    const d=Math.hypot(p.x-x,p.y-y);
    if(d<bd){bd=d;best=p;}
  }
  return best;
}
function nearestEnemy(x,y){
  let best=null,bd=1e9;
  for(const e of game.cur.live){
    const d=Math.hypot(e.x-x,e.y-y);
    if(d<bd){bd=d;best=e;}
  }
  return best;
}

// ---------- fx ----------
function burst(x,y,color,n,spd){
  for(let i=0;i<n;i++){const a=Math.random()*6.3,v=(0.3+Math.random()*.7)*spd;
    game.parts.push({x,y,vx:Math.cos(a)*v,vy:Math.sin(a)*v,life:.35+Math.random()*.3,color,size:2+Math.random()*3});}
}
function floatText(x,y,txt,color){game.floats.push({x,y,txt,color,life:1});}

// ---------- loot & crafting ----------
function dropLoot(room,e){
  if(e.boss)return;
  const ch=Math.random();let mat=null;
  if(e.type==='bat'){if(ch<.5)mat='feather';else if(ch<.7)mat='bone';}
  else if(e.type==='bear'){if(ch<.55)mat='sinew';else if(ch<.9)mat='bone';}
  else if(e.type==='dino'){if(ch<.55)mat='fang';else if(ch<.85)mat='bone';}
  if(mat)room.drops.push({x:e.x,y:e.y,mat,t:0});
}
function craft(i){
  const r=REC[i];if(!r)return;
  if(game.crafted[r.id]){showMsg('ALREADY MADE.');return;}
  if(r.kind==='active'&&game.actives.length>=2){showMsg('TWO HANDS ONLY. TOOLS FULL.');return;}
  if(r.kind==='passive'){
    const np=REC.filter(x=>x.kind==='passive'&&game.crafted[x.id]).length;
    if(np>=3){showMsg('CARRY TOO MUCH. THREE CRAFTS ONLY.');return;}
  }
  for(const m in r.cost)if((game.mats[m]||0)<r.cost[m]){showMsg('NEED '+Object.keys(r.cost).map(k=>k.toUpperCase()).join(' + ')+'.');return;}
  for(const m in r.cost)game.mats[m]-=r.cost[m];
  game.crafted[r.id]=true;
  if(r.kind==='active')game.actives.push(r.id);
  for(const P of game.players){
    if(r.id==='spear'){P.dmg+=1;}
    else if(r.id==='edge'){P.dmg+=2;}
    else if(r.id==='totem'){P.maxhp+=2;P.hp=Math.min(P.maxhp,P.hp+2);}
    else if(r.id==='fletch'){P.cdMax=Math.max(.14,P.cdMax*.65);}
  }
  if(r.id==='spear')game.pierce+=1;
  if(r.id==='atlatl')game.projMul=1.5;
  sfx('clear');
  showMsg(r.name+' MADE. '+r.fx);
}
function relicDrop(){
  for(const P of game.players){P.maxhp+=2;P.hp=P.maxhp;}
  game.hunger=100;
  game.mats.obsidian+=2;
  const m=MATS[Math.random()*MATS.length|0];game.mats[m]+=2;
  showMsg('TOWER RELIC TAKEN. THE TRIBE GROWS. (+1 HEART)');
}

// ---------- actives ----------
function aimOf(P){
  if(P.id===0){
    if(IS_TOUCH){
      if(aimMode==='twin'&&touch.aimId!==null&&Math.hypot(touch.aimDx,touch.aimDy)>10)
        return Math.atan2(touch.aimDy,touch.aimDx);
      const ne=nearestEnemy(P.x,P.y);
      if(ne)return Math.atan2(ne.y-P.y,ne.x-P.x);
      return Math.atan2(P.fdy,P.fdx);
    }
    return Math.atan2(mouse.y-ORY-P.y,mouse.x-ORX-P.x);
  }
  return Math.atan2(P.fdy,P.fdx);
}
function useActive(slot,P){
  if(!game||!P||P.down)return;
  const id=game.actives[slot];
  if(!id||game.acd[id]>0)return;
  const a=aimOf(P);
  if(id==='bola'){
    game.acd.bola=ACD_MAX.bola;
    game.bolas.push({x:P.x,y:P.y,vx:Math.cos(a)*TILE*7.5,vy:Math.sin(a)*TILE*7.5,life:1.4,rot:0});
    sfx('throw');
  } else if(id==='dart'){
    game.acd.dart=ACD_MAX.dart;
    game.stones.push({x:P.x,y:P.y,vx:Math.cos(a)*TILE*16,vy:Math.sin(a)*TILE*16,life:1.0,dmg:4,pierce:99,dart:true});
    sfx('throw');
  } else if(id==='fist'){
    game.acd.fist=ACD_MAX.fist;
    sfx('slam');shake=Math.min(shake+9,12);
    burst(P.x,P.y,'#c1642a',26,TILE*4);
    const room=game.cur;
    for(const e of room.live){
      const d=Math.hypot(e.x-P.x,e.y-P.y);
      if(d<TILE*2.4){
        e.hp-=2;e.hitFlash=.15;e.slow=Math.max(e.slow,1);
        const kn=TILE*7/(d/TILE+1);
        e.vx+=(e.x-P.x)/(d||1)*kn;e.vy+=(e.y-P.y)/(d||1)*kn;
        floatText(e.x,e.y-e.r-8,'-2','#c1642a');
        if(e.hp<=0)onEnemyDeath(room,e);
      }
    }
    for(const e2 of room.live)keepInRoom(e2);
    room.live=room.live.filter(e=>e.hp>0);
    checkClear(room);
  }
}
function onEnemyDeath(room,e){
  game.kills++;
  dropLoot(room,e);
  burst(e.x,e.y,'#d0392b',e.boss?34:18,TILE*(e.boss?5:3.6));
  floatText(e.x,e.y-e.r-14,e.boss?'FELLED!':'BONK!','#ff8c2e');
  if(e.boss){sfx('boss');shake=12;relicDrop();}
}
function checkClear(room){
  if(room.spawned&&room.live.length===0&&!room.cleared){
    room.cleared=true;sfx('clear');game.clearFlash=.5;
    if(room.type==='tower')showMsg('THE HOLE OPENS BELOW THE GUARDIAN...');
    else{
      showMsg('ROOM CLEAR. DOORS OPEN.');
      if(Math.random()<.4&&room.type!=='exit')room.items.push({type:'meat',ti:8,tj:5,bob:0});
    }
  }
}

// ---------- pause / restart ----------
function setPause(v){
  if(!game)return;
  game.paused=v;
  document.getElementById('pause').classList.toggle('hidden',!v);
}
function restartRoom(){
  if(!game)return;
  const room=game.cur;
  room.obst=null;room.live=[];room.drops=[];room.items=[];
  room.grok=null;room.shrine=null;room.slabT=0;room.tileHP={};
  room.cleared=false;room.spawned=false;
  buildRoom(room,game.depth);
  game.stones.length=0;game.spits.length=0;game.bolas.length=0;game.parts.length=0;game.floats.length=0;
  for(const p of game.players){if(p.down){p.down=false;p.hp=2;}}
  if(room.type==='tower'){
    room.spawned=true;
    room.live.push(newBoss(game.towerTier));
    placePlayers(8.5*TILE,8.6*TILE);
  } else if(['normal','water','dino','exit','treasure'].includes(room.type)&&room.type!=='start'){
    placePlayers(8.5*TILE,8.8*TILE);
    spawnEnemies(room,game.depth,'s');
    if(room.live.length>0){room.slabT=.35;}
    else room.cleared=true;
  } else {
    room.spawned=true;room.cleared=true;
    placePlayers(8.5*TILE,5.5*TILE);
  }
  setPause(false);
  showMsg('THE CAVE FORGETS. AGAIN.');
}
function restartRun(){setPause(false);start(game&&game.twoP?2:1);}
function goTitle(){
  setPause(false);
  document.getElementById('death').classList.add('hidden');
  document.getElementById('overlay').classList.remove('hidden');
  game=null;
}
document.getElementById('pbresume').addEventListener('click',()=>setPause(false));
document.getElementById('pbroom').addEventListener('click',restartRoom);
document.getElementById('pbrun').addEventListener('click',restartRun);
document.getElementById('pbtitle').addEventListener('click',goTitle);

// ---------- loop ----------
let last=performance.now();
function frame(now){
  requestAnimationFrame(frame);
  let dt=Math.min((now-last)/1000,.05);last=now;
  if(!game)return;
  if(game.dead){render();return;}
  if(game.paused){render();return;}
  if(game.trans){updateTrans(dt);render();return;}
  update(dt);render();
}
requestAnimationFrame(frame);

const P1KEYS={up:'KeyW',down:'KeyS',left:'KeyA',right:'KeyD',throw:'Space',a0:'KeyQ',a1:'KeyE'};
const P2KEYS={up:'ArrowUp',down:'ArrowDown',left:'ArrowLeft',right:'ArrowRight',throw:'Enter',a0:'ShiftRight',a1:'ControlRight'};

function update(dt){
  const room=game.cur;
  if(msgTimer>0){msgTimer-=dt;if(msgTimer<=0)document.getElementById('msg').style.opacity=0;}
  if(game.craftOpen)return;
  game.time+=dt;
  if(game.clearFlash>0)game.clearFlash-=dt;
  for(const k in game.acd)if(game.acd[k]>0)game.acd[k]-=dt;

  // ---- players ----
  for(const P of game.players){
    if(P.down)continue;
    const K=(P.id===0)?P1KEYS:P2KEYS;
    let ix=0,iy=0;
    if(keys[K.up]||(!game.twoP&&P.id===0&&keys['ArrowUp']))iy-=1;
    if(keys[K.down]||(!game.twoP&&P.id===0&&keys['ArrowDown']))iy+=1;
    if(keys[K.left]||(!game.twoP&&P.id===0&&keys['ArrowLeft']))ix-=1;
    if(keys[K.right]||(!game.twoP&&P.id===0&&keys['ArrowRight']))ix+=1;
    // touch joystick (P1)
    if(P.id===0&&touch.moveId!==null){
      const m=Math.hypot(touch.moveDx,touch.moveDy);
      if(m>8){ix=touch.moveDx/52;iy=touch.moveDy/52;}
    }
    const inWater=cellAtPx(room,P.x,P.y)===O_WATER;
    const spd=(inWater?TILE*2.9:TILE*5.2);
    const len=Math.hypot(ix,iy)||1;
    const nl=Math.min(1,len);
    moveCircle(room,P,ix/len*spd*nl*dt,iy/len*spd*nl*dt,false);
    // player safety clamp (never through outer void)
    if(P.x<2)P.x=2;if(P.x>C*TILE-2)P.x=C*TILE-2;
    if(P.y<2)P.y=2;if(P.y>R*TILE-2)P.y=R*TILE-2;
    if(Math.abs(ix)>.01||Math.abs(iy)>.01){P.fdx=ix/len;P.fdy=iy/len;}
    if(P.id===0&&!IS_TOUCH)P.face=(mouse.x-ORX>P.x)?1:-1;
    else P.face=(P.fdx>=0?1:-1);
    P.walk=(Math.abs(ix)>.01||Math.abs(iy)>.01)?P.walk+dt*10:0;
    if(P.hurtCd>0)P.hurtCd-=dt;
    if(P.cd>0)P.cd-=dt;
    // throw
    let throwing=(P.id===0)?(keys[K.throw]||(!IS_TOUCH&&mouse.down)):keys[K.throw];
    if(P.id===0&&IS_TOUCH){
      if(aimMode==='twin')throwing=throwing||(touch.aimId!==null&&Math.hypot(touch.aimDx,touch.aimDy)>14);
      throwing=throwing||touch.firing;
    }
    if(throwing&&P.cd<=0){
      P.cd=P.cdMax;
      const a=aimOf(P);
      const sp=TILE*10.5*game.projMul;
      game.stones.push({x:P.x,y:P.y,vx:Math.cos(a)*sp,vy:Math.sin(a)*sp,life:1.2*game.projMul,dmg:P.dmg,pierce:game.pierce});
      sfx('throw');
    }
    if(keys[K.a0])useActive(0,P);
    if(keys[K.a1])useActive(1,P);
    const ti=P.x/TILE|0,tj=P.y/TILE|0;
    const d=isDoorTile(ti,tj);
    if(d&&room.doors[d]&&roomDoorsOpen(room)){startTrans(d);return;}
    P._inWater=inWater;
  }

  // ---- tribe hunger ----
  const anyWater=game.players.some(p=>!p.down&&p._inWater);
  game.hunger=Math.max(0,game.hunger-dt*(anyWater?1.6:.8)*(game.twoP?1.25:1)*DIFF[difficulty].hunger);
  if(game.hunger<=0){
    game.starveT+=dt;
    if(game.starveT>2.2){game.starveT=0;for(const p of alivePlayers())hurtPlayer(p,1,'STARVING');}
  }

  // ---- bolas ----
  for(let i=game.bolas.length-1;i>=0;i--){
    const b=game.bolas[i];
    b.x+=b.vx*dt;b.y+=b.vy*dt;b.life-=dt;b.rot+=dt*14;
    if(b.life<=0||solidAt(room,b.x,b.y,false)){burst(b.x,b.y,'#c9a06a',6,TILE*2);game.bolas.splice(i,1);continue;}
    for(const e of room.live){
      if(e.hp>0&&Math.hypot(e.x-b.x,e.y-b.y)<e.r+TILE*.14){
        e.hp-=1;e.hitFlash=.12;e.slow=2.2;
        burst(b.x,b.y,'#c9a06a',10,TILE*2.4);sfx('hit');
        floatText(e.x,e.y-e.r-8,'SNARED','#c9a06a');
        game.bolas.splice(i,1);
        if(e.hp<=0)onEnemyDeath(room,e);
        break;
      }
    }
  }

  // ---- stones ----
  for(let i=game.stones.length-1;i>=0;i--){
    const s=game.stones[i];
    s.x+=s.vx*dt;s.y+=s.vy*dt;s.life-=dt;
    if(s.life<=0){game.stones.splice(i,1);continue;}
    const ti=s.x/TILE|0,tj=s.y/TILE|0;
    if(solidAt(room,s.x,s.y,false)){
      const inRing=(ti<=0||tj<=0||ti>=C-1||tj>=R-1);
      const cell=(!inRing&&room.obst)?room.obst[tj][ti]:O_NONE;
      if(cell===O_ROCK||cell===O_ROOT||cell===O_OBROCK){
        const k=ti+','+tj;
        room.tileHP[k]=(room.tileHP[k]||1)-1;
        burst(s.x,s.y,cell===O_ROOT?'#a89d84':'#a39a8e',7,TILE*2.4);sfx('rock');
        if(room.tileHP[k]<=0){
          room.obst[tj][ti]=O_NONE;
          shake=Math.min(shake+2,6);
          const cx=(ti+.5)*TILE,cy=(tj+.5)*TILE;
          burst(cx,cy,'#6b5c4d',14,TILE*3);
          let mat=null,ch=Math.random();
          if(cell===O_ROCK&&ch<.6)mat='flint';
          else if(cell===O_ROOT&&ch<.9)mat='wood';
          else if(cell===O_OBROCK&&ch<.85)mat='obsidian';
          if(mat)room.drops.push({x:cx,y:cy,mat,t:0});
        }
      } else {
        burst(s.x,s.y,'#a39a8e',6,TILE*2.4);sfx('rock');
      }
      game.stones.splice(i,1);continue;
    }
    for(const e of room.live){
      if(e.hp>0&&Math.hypot(e.x-s.x,e.y-s.y)<e.r+TILE*.12){
        e.hp-=s.dmg;e.hitFlash=.12;
        if(!e.boss){e.vx+=s.vx*.12;e.vy+=s.vy*.12;}
        burst(s.x,s.y,s.dart?'#6a5490':'#d0392b',8,TILE*3);sfx('hit');shake=Math.min(shake+3.5,7);
        floatText(e.x,e.y-e.r-8,'-'+s.dmg,s.dart?'#b9a6e8':'#ffd166');
        if(e.hp<=0)onEnemyDeath(room,e);
        if(s.pierce>0){s.pierce--;}else{game.stones.splice(i,1);}
        break;
      }
    }
  }
  const before=room.live.length;
  room.live=room.live.filter(e=>e.hp>0);
  if(before>0)checkClear(room);

  // ---- spits ----
  for(let i=game.spits.length-1;i>=0;i--){
    const s=game.spits[i];
    s.x+=s.vx*dt;s.y+=s.vy*dt;s.life-=dt;
    if(s.life<=0||solidAt(room,s.x,s.y,false)){burst(s.x,s.y,'#8ac24a',5,TILE*1.8);game.spits.splice(i,1);continue;}
    let hitP=false;
    for(const p of alivePlayers()){
      if(Math.hypot(p.x-s.x,p.y-s.y)<p.r+TILE*.1){hurtPlayer(p,1,'SPIT');hitP=true;break;}
    }
    if(hitP)game.spits.splice(i,1);
  }

  // ---- enemies ----
  for(const e of room.live){
    e.t+=dt;if(e.hitFlash>0)e.hitFlash-=dt;if(e.spitCd>0)e.spitCd-=dt;
    if(e.slow>0)e.slow-=dt;
    const T=nearestPlayer(e.x,e.y);
    if(!T)break;
    if(e.boss){updateBoss(e,T,dt,room);continue;}
    const dToP=Math.hypot(T.x-e.x,T.y-e.y)||1;
    let tx,ty;
    if(e.ranged&&dToP<TILE*3.4){tx=(e.x-T.x)/dToP;ty=(e.y-T.y)/dToP;}
    else{tx=(T.x-e.x)/dToP;ty=(T.y-e.y)/dToP;}
    if(e.ranged&&e.spitCd<=0){
      e.spitCd=1.6;
      const a=Math.atan2(T.y-e.y,T.x-e.x);
      game.spits.push({x:e.x,y:e.y,vx:Math.cos(a)*TILE*4.4,vy:Math.sin(a)*TILE*4.4,life:2});
    }
    if(e.fly){tx+=Math.cos(e.t*7)*.55;ty+=Math.sin(e.t*5.3)*.55;}
    const eff=e.slow>0?e.spd*.35:e.spd;
    e.vx+=(tx*eff-e.vx)*Math.min(1,dt*6);
    e.vy+=(ty*eff-e.vy)*Math.min(1,dt*6);
    moveCircle(room,e,e.vx*dt,e.vy*dt,e.fly);
    keepInRoom(e);
    for(const p of alivePlayers()){
      if(Math.hypot(p.x-e.x,p.y-e.y)<e.r+p.r-2)hurtPlayer(p,e.dmg,e.type.toUpperCase());
    }
  }

  // ---- drops ----
  for(let i=room.drops.length-1;i>=0;i--){
    const d=room.drops[i];d.t+=dt;
    let taken=false;
    for(const p of alivePlayers()){
      if(Math.hypot(p.x-d.x,p.y-d.y)<p.r+TILE*.4){taken=true;break;}
    }
    if(taken){
      game.mats[d.mat]++;
      floatText(d.x,d.y-12,'+'+d.mat.toUpperCase(),'#e8d9c0');
      sfx('pickup');burst(d.x,d.y,'#e8d9c0',6,TILE*1.6);
      room.drops.splice(i,1);
    }
  }

  // ---- shrine ----
  if(room.shrine&&!room.shrine.used){
    const shx=(room.shrine.ti+.5)*TILE,shy=(room.shrine.tj+.5)*TILE;
    for(const p of alivePlayers()){
      if(Math.hypot(p.x-shx,p.y-shy)<TILE*1.1){
        room.shrine.used=true;sfx('grok');
        for(const q of game.players)if(!q.down)q.hp=Math.min(q.maxhp,q.hp+2);
        const m=MATS[Math.random()*MATS.length|0];
        game.mats[m]++;
        showMsg('URM SAYS NOTHING. URM GIVES '+m.toUpperCase()+'.');
        burst(shx,shy-10,'#c1642a',16,TILE*2.2);
        break;
      }
    }
  }

  // ---- grok ----
  if(room.grok){
    const G=room.grok;G.t+=dt;
    const gx=(G.ti+.5)*TILE,gy=(G.tj+.5)*TILE;
    if(!G.gave){
      for(const p of alivePlayers()){
        if(Math.hypot(p.x-gx,p.y-gy)<TILE*1.1){
          G.gave=true;sfx('grok');
          game.hunger=Math.min(100,game.hunger+35);
          for(const q of game.players)if(!q.down)q.hp=Math.min(q.maxhp,q.hp+1);
          if(Math.random()<.5){const m=MATS[Math.random()*MATS.length|0];game.mats[m]++;floatText(gx,gy-TILE,'+'+m.toUpperCase(),'#e8d9c0');}
          showMsg(GROK_LINES[Math.random()*GROK_LINES.length|0]);
          burst(gx,gy-10,'#ffd166',14,TILE*2);
          break;
        }
      }
    }
  }

  // ---- items ----
  for(let i=room.items.length-1;i>=0;i--){
    const it=room.items[i];
    const x=(it.ti+.5)*TILE,y=(it.tj+.5)*TILE;
    let taker=null;
    for(const p of alivePlayers()){
      if(Math.hypot(p.x-x,p.y-y)<p.r+TILE*.35){taker=p;break;}
    }
    if(taker){
      if(it.type==='meat'){game.hunger=Math.min(100,game.hunger+38);floatText(x,y-14,'+MEAT','#ffb54d');}
      else if(it.type==='heart'){taker.hp=Math.min(taker.maxhp,taker.hp+2);floatText(x,y-14,'+HP','#ff6a5e');}
      else if(it.type==='flint_item'){game.mats.flint+=2;game.mats.obsidian+=1;floatText(x,y-14,'+SHINIES','#b9c6cf');}
      burst(x,y,'#ffd166',12,TILE*2.4);sfx('pickup');
      room.items.splice(i,1);
    }
  }

  // ---- exit hole ----
  if((room.type==='exit'||room.type==='tower')&&roomDoorsOpen(room)){
    for(const p of alivePlayers()){
      if(Math.hypot(p.x-8.5*TILE,p.y-5.5*TILE)<TILE*.55){
        sfx('stairs');shake=6;
        if(game.mode==='cave'&&game.depth%3===0){
          game.towerTier=game.depth/3;
          newTowerFloor();
        } else {
          game.depth++;
          newCaveFloor();
        }
        return;
      }
    }
  }

  // ---- particles / floats ----
  for(let i=game.parts.length-1;i>=0;i--){const p=game.parts[i];p.x+=p.vx*dt;p.y+=p.vy*dt;p.vx*=.9;p.vy*=.9;p.life-=dt;if(p.life<=0)game.parts.splice(i,1);}
  for(let i=game.floats.length-1;i>=0;i--){const f=game.floats[i];f.y-=28*dt;f.life-=dt;if(f.life<=0)game.floats.splice(i,1);}
  if(shake>0)shake=Math.max(0,shake-dt*22);
}

// ---------- boss AI ----------
function updateBoss(e,T,dt,room){
  if(e.state==='chase'){
    e.atkT-=dt;
    const d=Math.hypot(T.x-e.x,T.y-e.y)||1;
    const eff=e.slow>0?e.spd*.35:e.spd;
    e.vx+=((T.x-e.x)/d*eff-e.vx)*Math.min(1,dt*4);
    e.vy+=((T.y-e.y)/d*eff-e.vy)*Math.min(1,dt*4);
    moveCircle(room,e,e.vx*dt,e.vy*dt,false);
    if(e.atkT<=0){e.state='wind';e.wind=.7;e.vx=0;e.vy=0;}
    if(e.serpent&&e.spitCd<=0){
      e.spitCd=2.4;
      const base=Math.atan2(T.y-e.y,T.x-e.x);
      for(const off of [-.3,0,.3]){
        game.spits.push({x:e.x,y:e.y,vx:Math.cos(base+off)*TILE*4.6,vy:Math.sin(base+off)*TILE*4.6,life:2.2});
      }
    }
  } else if(e.state==='wind'){
    e.wind-=dt;
    e.hitFlash=.05;
    if(e.wind<=0){
      e.state='charge';e.charge=.85;
      const d=Math.hypot(T.x-e.x,T.y-e.y)||1;
      e.cdx=(T.x-e.x)/d;e.cdy=(T.y-e.y)/d;
      sfx('slam');
    }
  } else if(e.state==='charge'){
    e.charge-=dt;
    moveCircle(room,e,e.cdx*TILE*6.5*dt,e.cdy*TILE*6.5*dt,false);
    keepInRoom(e);
    if((game.time*30|0)%2===0)burst(e.x,e.y+e.r*.6,'#6b5c4d',2,TILE*1.2);
    if(e.charge<=0){e.state='chase';e.atkT=2.6+Math.random();}
  }
  if(!e.summoned&&e.hp<=e.maxhp*.5){
    e.summoned=true;
    showMsg(e.serpent?'THE PRIEST CALLS THE DEEP...':'GHUR ROARS FOR HIS KIN...');
    const adds=e.serpent?['bat','dino']:['bat','bat'];
    if(e.tier>=3)adds.push('dino');
    for(const a of adds){
      const ang=Math.random()*6.3;
      room.live.push(newEnemy(a,e.x+Math.cos(ang)*TILE*2,e.y+Math.sin(ang)*TILE*2,game.depth));
    }
    sfx('boss');shake=7;
  }
  for(const p of alivePlayers()){
    if(Math.hypot(p.x-e.x,p.y-e.y)<e.r+p.r-2)hurtPlayer(p,e.dmg,e.name);
  }
}

// ---------- transitions ----------
function startTrans(dir){
  const room=game.cur;
  const nx=room.gx+DIRV[dir][0],ny=room.gy+DIRV[dir][1];
  const next=game.rooms[key(nx,ny)];
  if(!next)return;
  buildRoom(next,game.depth);
  game.stones.length=0;game.spits.length=0;game.bolas.length=0;game.parts.length=0;game.floats.length=0;
  game.trans={dir,from:room,to:next,t:0};
}
function updateTrans(dt){
  const T=game.trans;
  T.t+=dt/0.45;
  if(T.t>=1){
    const dir=T.dir,next=T.to;
    game.cur=next;
    next.visited=true;
    const od=DOOR[OPP[dir]];
    const bx=(od.ti+.5)*TILE+(OPP[dir]==='w'?TILE*.9:OPP[dir]==='e'?-TILE*.9:0);
    const by=(od.tj+.5)*TILE+(OPP[dir]==='n'?TILE*.9:OPP[dir]==='s'?-TILE*.9:0);
    game.players.forEach((p,i)=>{
      const perp=(OPP[dir]==='w'||OPP[dir]==='e')?{x:0,y:1}:{x:1,y:0};
      p.x=bx+(i?perp.x*TILE*.5:game.twoP?-perp.x*TILE*.5:0);
      p.y=by+(i?perp.y*TILE*.5:game.twoP?-perp.y*TILE*.5:0);
    });
    revivePlayers();
    game.trans=null;
    if(!next.spawned&&['normal','water','dino','exit','treasure'].includes(next.type)){
      spawnEnemies(next,game.depth,dir);
      if(next.live.length>0){sfx('slam');shake=5;next.slabT=.35;}
      else next.cleared=true;
    } else if(!next.spawned){
      next.spawned=true;next.cleared=true;
    }
  }
}

// ---------- damage ----------
function hurtPlayer(P,dmg,from){
  if(P.hurtCd>0||P.down)return;
  P.hurtCd=.85;P.hp-=dmg;
  sfx('hurt');shake=Math.min(shake+6,10);
  burst(P.x,P.y,'#d0392b',14,TILE*3);
  floatText(P.x,P.y-TILE*.6,'-'+dmg,'#ff5a4e');
  if(P.hp<=0){
    P.hp=0;P.down=true;
    burst(P.x,P.y,'#cfc2a8',20,TILE*3);
    if(alivePlayers().length===0)die(from);
    else showMsg('A HUNTER FALLS. CLEAR THE ROOM. URM MAY GIVE ANOTHER STONE.');
  }
}
function die(from){
  game.dead=true;sfx('die');
  const ov=document.getElementById('death');
  ov.classList.remove('hidden');
  ov.innerHTML=`
    <div style="font-size:14px;color:#c8402e;letter-spacing:5px;margin-bottom:12px">☠ THE TRIBE ENDS HERE ☠</div>
    <h1 style="font-size:28px;letter-spacing:4px;color:#c1642a;text-shadow:0 3px 10px #000;margin-bottom:16px;font-weight:800">SLAIN BY ${from||'THE CAVE'}</h1>
    <div style="font-size:15px;line-height:2;margin-bottom:20px">REACHED ${game.mode==='tower'?'TOWER '+game.towerTier:'CAVE '+game.depth}<br>BONKED <b style="color:#ffa63e">${game.kills}</b> BEAST${game.kills===1?'':'S'}</div>
    <div><button onclick="deathRestart()">ROCK AGAIN</button>
    <button onclick="goTitle()">TITLE</button></div>`;
}
function deathRestart(){
  document.getElementById('death').classList.add('hidden');
  start(game&&game.twoP?2:1);
}

// ---------- render ----------
function easeInOut(t){return t<.5?2*t*t:1-Math.pow(-2*t+2,2)/2;}
function render(){
  resetT(ctx);
  ctx.fillStyle=game.mode==='tower'?'#08080c':'#0a0705';ctx.fillRect(0,0,VW,VH);
  const sx=(Math.random()-.5)*shake,sy=(Math.random()-.5)*shake;

  if(game.trans){
    const T=game.trans,e=easeInOut(Math.min(1,T.t));
    const dx=DIRV[T.dir][0]*C*TILE,dy=DIRV[T.dir][1]*R*TILE;
    renderRoom(T.from,ORX-dx*e+sx,ORY-dy*e+sy,false);
    renderRoom(T.to,ORX+dx*(1-e)+sx,ORY+dy*(1-e)+sy,false);
    const od=DOOR[OPP[T.dir]];
    game.players.forEach((p,i)=>{
      drawPlayerScreen(p,ORX+dx*(1-e)+(od.ti+.5)*TILE+(i?TILE*.4:game.twoP?-TILE*.4:0)+sx,
                        ORY+dy*(1-e)+(od.tj+.5)*TILE+sy);
    });
  } else {
    renderRoom(game.cur,ORX+sx,ORY+sy,true);
  }
  renderLight();
  drawHUD();
  drawMinimap();
  if(IS_TOUCH&&!game.craftOpen)drawTouchUI();
  drawCraftPanel();
}

function renderRoom(room,ox,oy,active){
  const s=room.seed||1;
  const tower=room.type==='tower';
  ctx.save();ctx.translate(ox,oy);
  for(let j=0;j<R;j++)for(let i=0;i<C;i++){
    const x=i*TILE,y=j*TILE,v=hash(i,j,s);
    const border=(i===0||j===0||i===C-1||j===R-1);
    if(border){
      const d=isDoorTile(i,j);
      ctx.fillStyle=tower?(v<.5?'#15151d':'#1a1a24'):(v<.5?'#241a10':'#2a1e13');
      ctx.fillRect(x,y,TILE+1,TILE+1);
      if(j===0){
        const wg=ctx.createLinearGradient(0,y+TILE-10,0,y+TILE);
        wg.addColorStop(0,tower?'#2a2a3a':'#43331f');
        wg.addColorStop(1,tower?'#3f3f56':'#6b5236');
        ctx.fillStyle=wg;ctx.fillRect(x,y+TILE-10,TILE+1,10);
      }
      if(j===0&&!d&&v>.62&&v<.75)drawPainting(x,y,v,tower);
      if(d&&room.doors[d]){
        const open=roomDoorsOpen(room);
        ctx.fillStyle='#100a06';
        if(d==='n'||d==='s')ctx.fillRect(x+4,y,TILE-8,TILE);else ctx.fillRect(x,y+4,TILE,TILE-8);
        if(!open){
          const sl=room.slabT>0?Math.sin(room.slabT*40)*2:0;
          ctx.drawImage(SPR.slab,x+3+sl,y+3,TILE-6,TILE-6);
        } else {
          ctx.fillStyle='rgba(255,166,62,.1)';
          ctx.fillRect(d==='n'||d==='s'?x+4:x,d==='n'||d==='s'?y:y+4,d==='n'||d==='s'?TILE-8:TILE,d==='n'||d==='s'?TILE:TILE-8);
        }
      }
    } else {
      ctx.fillStyle=tower?(v<.5?'#212129':'#252532'):(v<.5?'#352a20':(v<.8?'#392e20':'#31281e'));
      ctx.fillRect(x,y,TILE+1,TILE+1);
      if(v>.82){
        ctx.fillStyle=tower?'rgba(255,255,255,.025)':'rgba(255,200,140,.03)';
        ctx.beginPath();ctx.arc(x+TILE*(.3+v*.4),y+TILE*(.3+v*.3),TILE*.4,0,7);ctx.fill();
      }
      const cell=room.obst?room.obst[j][i]:O_NONE;
      if(cell===O_WATER){
        const wgr=ctx.createLinearGradient(0,y,0,y+TILE);
        wgr.addColorStop(0,'#265a63');wgr.addColorStop(1,'#183f47');
        ctx.fillStyle=wgr;ctx.fillRect(x,y,TILE+1,TILE+1);
        ctx.strokeStyle='rgba(120,210,220,.35)';ctx.lineWidth=2;
        const w=Math.sin(game.time*2+i*1.3+j*.8)*3;
        ctx.beginPath();ctx.moveTo(x+4,y+TILE*.35+w);
        ctx.quadraticCurveTo(x+TILE/2,y+TILE*.35-w,x+TILE-4,y+TILE*.35+w);ctx.stroke();
        ctx.beginPath();ctx.moveTo(x+8,y+TILE*.68-w);
        ctx.quadraticCurveTo(x+TILE/2,y+TILE*.68+w,x+TILE-8,y+TILE*.68-w);ctx.stroke();
      } else if(cell===O_ROCK||cell===O_OBROCK){
        ctx.drawImage(cell===O_OBROCK?SPR.obrock:SPR.rock,x+TILE*.02,y+TILE*.02,TILE*.96,TILE*.96);
        const hp=room.tileHP[i+','+j],mx=cell===O_OBROCK?4:3;
        if(hp!==undefined&&hp<mx){
          ctx.strokeStyle='rgba(0,0,0,.55)';ctx.lineWidth=2;
          ctx.beginPath();ctx.moveTo(x+TILE*.3,y+TILE*.35);ctx.lineTo(x+TILE*.55,y+TILE*.6);
          if(hp<=mx-2){ctx.moveTo(x+TILE*.65,y+TILE*.3);ctx.lineTo(x+TILE*.45,y+TILE*.7);}
          ctx.stroke();
        }
      } else if(cell===O_ROOT){
        ctx.drawImage(SPR.root,x+TILE*.05,y,TILE*.9,TILE*.98);
        const hp=room.tileHP[i+','+j];
        if(hp!==undefined&&hp<2){
          ctx.strokeStyle='rgba(0,0,0,.5)';ctx.lineWidth=2;
          ctx.beginPath();ctx.moveTo(x+TILE*.4,y+TILE*.3);ctx.lineTo(x+TILE*.6,y+TILE*.6);ctx.stroke();
        }
      } else if(cell===O_BONES){
        ctx.save();ctx.translate(x+TILE/2,y+TILE/2);
        ctx.rotate(hash(j,i,s)*3);
        ctx.drawImage(SPR.bone,-TILE*.25,-TILE*.25,TILE*.5,TILE*.5);
        ctx.restore();
      }
    }
  }

  // soft room vignette (depth without noise)
  const vg=ctx.createRadialGradient(C*TILE/2,R*TILE/2,TILE*3,C*TILE/2,R*TILE/2,TILE*9);
  vg.addColorStop(0,'rgba(0,0,0,0)');vg.addColorStop(1,'rgba(0,0,0,.32)');
  ctx.fillStyle=vg;ctx.fillRect(TILE,TILE,(C-2)*TILE,(R-2)*TILE);

  // exit hole
  if(room.type==='exit'||room.type==='tower'){
    const cx=8.5*TILE,cy=5.5*TILE;
    const open=roomDoorsOpen(room);
    const hg=ctx.createRadialGradient(cx,cy,TILE*.1,cx,cy,TILE*.75);
    hg.addColorStop(0,'#000');hg.addColorStop(.7,'#0a0705');hg.addColorStop(1,'rgba(28,19,12,.9)');
    ctx.fillStyle=hg;
    ctx.beginPath();ctx.ellipse(cx,cy,TILE*.72,TILE*.52,0,0,7);ctx.fill();
    ctx.strokeStyle='#1c130c';ctx.lineWidth=4;ctx.stroke();
    if(!open){
      ctx.drawImage(SPR.slab,cx-TILE*.62,cy-TILE*.5,TILE*1.24,TILE*1.0);
    } else {
      const pulse=Math.sin(game.time*3)*.15+.3;
      ctx.fillStyle='rgba(255,166,62,'+pulse*.25+')';
      ctx.beginPath();ctx.ellipse(cx,cy,TILE*.95,TILE*.7,0,0,7);ctx.fill();
    }
  }

  // shrine
  if(room.shrine){
    const shx=(room.shrine.ti+.5)*TILE,shy=(room.shrine.tj+.5)*TILE;
    ell(ctx,shx,shy+TILE*.5,TILE*.42,TILE*.12,'rgba(0,0,0,.35)');
    ctx.drawImage(SPR.shrine,shx-TILE*.55,shy-TILE*.75,TILE*1.1,TILE*1.35);
    if(!room.shrine.used){
      const g=Math.sin(game.time*3)*.08+.2;
      ctx.fillStyle='rgba(193,100,42,'+g+')';
      ctx.beginPath();ctx.arc(shx,shy,TILE*.9,0,7);ctx.fill();
      ctx.fillStyle='#c1642a';ctx.font='bold '+Math.max(11,TILE*.2)+'px Trebuchet MS';ctx.textAlign='center';
      ctx.fillText('urm',shx,shy-TILE*.95);ctx.textAlign='left';
    }
  }

  // drops (warm glow: loot pops)
  for(const d of room.drops){
    const bob=Math.sin(game.time*4+d.t)*TILE*.05;
    const gl=Math.sin(game.time*5+d.t)*.06+.16;
    ctx.fillStyle='rgba(255,209,102,'+gl+')';
    ctx.beginPath();ctx.arc(d.x,d.y+bob,TILE*.3,0,7);ctx.fill();
    ell(ctx,d.x,d.y+TILE*.18,TILE*.14,TILE*.05,'rgba(0,0,0,.3)');
    ctx.drawImage(SPR[d.mat],d.x-TILE*.22,d.y-TILE*.22+bob,TILE*.44,TILE*.44);
  }

  // items
  for(const it of room.items){
    const x=(it.ti+.5)*TILE,y=(it.tj+.5)*TILE;
    if(it.pedestal)ctx.drawImage(SPR.rock,x-TILE*.42,y-TILE*.1,TILE*.84,TILE*.62);
    const bob=Math.sin(game.time*3+(it.bob||0))*TILE*.06;
    ell(ctx,x,y+TILE*.3,TILE*.2,TILE*.07,'rgba(0,0,0,.3)');
    const spr=it.type==='meat'?SPR.meat:it.type==='heart'?SPR.heart:SPR.flint;
    const iy=y-(it.pedestal?TILE*.32:0)+bob;
    ctx.drawImage(spr,x-TILE*.3,iy-TILE*.3,TILE*.6,TILE*.6);
    if(it.pedestal){
      const g=Math.sin(game.time*4)*.1+.22;
      ctx.fillStyle='rgba(255,209,102,'+g+')';
      ctx.beginPath();ctx.arc(x,y-TILE*.32,TILE*.45,0,7);ctx.fill();
    }
  }

  // grok
  if(room.grok){
    const G=room.grok;
    const gx=(G.ti+.5)*TILE,gy=(G.tj+.5)*TILE;
    ell(ctx,gx,gy+TILE*.45,TILE*.24,TILE*.09,'rgba(0,0,0,.3)');
    const gb=Math.sin(G.t*2)*2;
    ctx.drawImage(SPR.grok,gx-TILE*.5,gy-TILE*.55+gb,TILE,TILE);
    if(!G.gave){
      ctx.fillStyle='#e8d9c0';ctx.font='bold '+Math.max(11,TILE*.22)+'px Trebuchet MS';ctx.textAlign='center';
      ctx.fillText('grok?',gx,gy-TILE*.75);ctx.textAlign='left';
    }
  }

  if(active){
    for(const sp of game.spits){
      const spg=ctx.createRadialGradient(sp.x,sp.y,1,sp.x,sp.y,TILE*.11);
      spg.addColorStop(0,'#c8f088');spg.addColorStop(1,'#6a9c38');
      ctx.fillStyle=spg;ctx.beginPath();ctx.arc(sp.x,sp.y,TILE*.1,0,7);ctx.fill();
    }
    for(const st of game.stones){
      if(st.dart){
        ctx.save();ctx.translate(st.x,st.y);ctx.rotate(Math.atan2(st.vy,st.vx));
        ctx.drawImage(SPR.obsidian,-TILE*.22,-TILE*.22,TILE*.44,TILE*.44);
        ctx.restore();
      } else {
        ctx.drawImage(SPR.stone,st.x-TILE*.16,st.y-TILE*.16,TILE*.32,TILE*.32);
      }
    }
    for(const b of game.bolas){
      ctx.save();ctx.translate(b.x,b.y);ctx.rotate(b.rot);
      ctx.drawImage(SPR.bola,-TILE*.22,-TILE*.22,TILE*.44,TILE*.44);
      ctx.restore();
    }
    for(const e of game.cur.live){
      ell(ctx,e.x,e.y+e.r*.9,e.r,e.r*.38,'rgba(0,0,0,.32)');
      const bobY=e.fly?Math.sin(e.t*8)*TILE*.08:0;
      const w=S*e.sc;
      ctx.save();ctx.translate(e.x,e.y+bobY);
      if(e.vx<0||(e.state==='charge'&&e.cdx<0))ctx.scale(-1,1);
      if(e.hitFlash>0)ctx.filter='brightness(2.2)';
      ctx.drawImage(e.spr,-w/2,-w/2,w,w);
      ctx.filter='none';ctx.restore();
      if(e.slow>0){ctx.strokeStyle='rgba(201,160,106,.7)';ctx.lineWidth=2;ctx.beginPath();ctx.arc(e.x,e.y,e.r+3,0,7);ctx.stroke();}
      if(!e.boss&&e.hp<e.maxhp){
        ctx.fillStyle='rgba(0,0,0,.6)';roundRect(ctx,e.x-e.r,e.y-e.r-11,e.r*2,5,2.5);ctx.fill();
        ctx.fillStyle='#c8402e';roundRect(ctx,e.x-e.r+1,e.y-e.r-10,(e.r*2-2)*(e.hp/e.maxhp),3,1.5);ctx.fill();
      }
    }
    const boss=game.cur.live.find(e=>e.boss);
    if(boss){
      const bw=C*TILE*.6,bx2=(C*TILE-bw)/2,by2=TILE*.35;
      ctx.fillStyle='rgba(0,0,0,.6)';roundRect(ctx,bx2-4,by2-4,bw+8,18,8);ctx.fill();
      ctx.strokeStyle='#57422c';ctx.lineWidth=2;ctx.stroke();
      ctx.fillStyle='#c8402e';roundRect(ctx,bx2,by2,Math.max(2,bw*(boss.hp/boss.maxhp)),10,5);ctx.fill();
      ctx.fillStyle='#e8d9c0';ctx.font='bold '+Math.max(11,TILE*.2)+'px Trebuchet MS';ctx.textAlign='center';
      ctx.fillText(boss.name,C*TILE/2,by2+26);ctx.textAlign='left';
    }
    for(const P of game.players){
      if(P.down){
        ctx.save();ctx.translate(P.x,P.y);ctx.rotate(.4);
        ctx.drawImage(SPR.bone,-TILE*.3,-TILE*.3,TILE*.6,TILE*.6);
        ctx.restore();
        continue;
      }
      ell(ctx,P.x,P.y+TILE*.45,TILE*.22,TILE*.08,'rgba(0,0,0,.35)');
      drawPlayerLocal(P);
    }
    for(const p of game.parts){
      ctx.globalAlpha=Math.max(0,p.life*2.5);ctx.fillStyle=p.color;
      ctx.beginPath();ctx.arc(p.x,p.y,p.size/1.6,0,7);ctx.fill();
    }
    ctx.globalAlpha=1;
    ctx.font='bold '+Math.max(13,TILE*.26)+'px Trebuchet MS';ctx.textAlign='center';
    for(const f of game.floats){
      ctx.globalAlpha=Math.max(0,f.life);
      ctx.fillStyle='rgba(0,0,0,.7)';ctx.fillText(f.txt,f.x+1.5,f.y+1.5);
      ctx.fillStyle=f.color;ctx.fillText(f.txt,f.x,f.y);
    }
    ctx.globalAlpha=1;ctx.textAlign='left';
    if(room.slabT>0)room.slabT-=1/60;
  }
  ctx.restore();
}
function roundRect(c,x,y,w,h,r){
  c.beginPath();
  if(c.roundRect){c.roundRect(x,y,w,h,r);}
  else{c.rect(x,y,w,h);}
}
function drawPlayerLocal(P){
  const hop=Math.abs(Math.sin(P.walk))*TILE*.06;
  const blink=P.hurtCd>0&&(game.time*20|0)%2===0;
  if(blink)return;
  ctx.save();
  ctx.translate(P.x,P.y-hop);
  ctx.scale(P.face<0?-1:1,1);
  const w=TILE*1.05;
  ctx.drawImage(P.id===0?SPR.caveman:SPR.caveman2,-w/2,-w*.58,w,w);
  ctx.restore();
}
function drawPlayerScreen(P,ax,ay){
  ctx.save();resetT(ctx);ctx.translate(ax,ay);
  ctx.scale(P.face<0?-1:1,1);
  const w=TILE*1.05;
  if(!P.down)ctx.drawImage(P.id===0?SPR.caveman:SPR.caveman2,-w/2,-w*.58,w,w);
  ctx.restore();
}
function drawPainting(x,y,v,tower){
  const o=tower?'#5f8a4a':'#a8552a';
  ctx.fillStyle=o;ctx.strokeStyle=o;ctx.globalAlpha=.7;
  const k=(v*100|0)%4;
  const u=TILE/14;
  ctx.lineWidth=u*.9;ctx.lineCap='round';
  if(tower){
    ctx.beginPath();
    for(let a=0;a<=10;a++){
      const px=x+3*u+a*u,py=y+6*u+Math.sin(a*1.2+v*10)*2*u;
      if(a===0)ctx.moveTo(px,py);else ctx.lineTo(px,py);
    }
    ctx.stroke();
  } else if(k===0){ // bison
    ctx.beginPath();ctx.ellipse(x+7*u,y+6.5*u,3.4*u,1.8*u,0,0,7);ctx.fill();
    ctx.beginPath();ctx.moveTo(x+4.5*u,y+8*u);ctx.lineTo(x+4.5*u,y+10*u);ctx.moveTo(x+9.5*u,y+8*u);ctx.lineTo(x+9.5*u,y+10*u);ctx.stroke();
    ctx.beginPath();ctx.arc(x+10.6*u,y+5*u,1.1*u,0,7);ctx.fill();
    ctx.beginPath();ctx.moveTo(x+11.2*u,y+4*u);ctx.lineTo(x+12*u,y+3*u);ctx.stroke();
  } else if(k===1){ // handprint
    ctx.beginPath();ctx.arc(x+7*u,y+7*u,2.2*u,0,7);ctx.fill();
    for(let f=0;f<5;f++){
      const ang=-2.2+f*.5;
      ctx.beginPath();ctx.moveTo(x+7*u+Math.cos(ang)*2*u,y+7*u+Math.sin(ang)*2*u);
      ctx.lineTo(x+7*u+Math.cos(ang)*4*u,y+7*u+Math.sin(ang)*4*u);ctx.stroke();
    }
  } else if(k===2){ // hunter
    ctx.beginPath();ctx.arc(x+6.5*u,y+3.5*u,u,0,7);ctx.fill();
    ctx.beginPath();ctx.moveTo(x+6.5*u,y+4.5*u);ctx.lineTo(x+6.5*u,y+7.5*u);
    ctx.moveTo(x+6.5*u,y+7.5*u);ctx.lineTo(x+5.4*u,y+10*u);
    ctx.moveTo(x+6.5*u,y+7.5*u);ctx.lineTo(x+7.6*u,y+10*u);
    ctx.moveTo(x+6.5*u,y+5.5*u);ctx.lineTo(x+10.5*u,y+4.5*u);ctx.stroke();
  } else { // spiral
    ctx.beginPath();
    for(let a=0;a<16;a++){
      const r=.3*u+a*.32*u,ang=a*.62;
      const px=x+7*u+Math.cos(ang)*r,py=y+6.5*u+Math.sin(ang)*r*.75;
      if(a===0)ctx.moveTo(px,py);else ctx.lineTo(px,py);
    }
    ctx.stroke();
  }
  ctx.globalAlpha=1;
}

// ---------- lighting ----------
function renderLight(){
  resetT(lctx);
  lctx.globalCompositeOperation='source-over';
  lctx.clearRect(0,0,VW,VH);
  const dark=game.mode==='tower'?.68:Math.min(.8,.5+game.depth*.035);
  lctx.fillStyle='rgba(5,3,2,'+dark+')';
  lctx.fillRect(0,0,VW,VH);
  lctx.globalCompositeOperation='destination-out';
  function light(x,y,rad,str){
    const g=lctx.createRadialGradient(x,y,rad*.2,x,y,rad);
    g.addColorStop(0,'rgba(0,0,0,'+str+')');g.addColorStop(1,'rgba(0,0,0,0)');
    lctx.fillStyle=g;lctx.beginPath();lctx.arc(x,y,rad,0,7);lctx.fill();
  }
  const flick=Math.sin(game.time*8)*8;
  if(game.trans){
    const T=game.trans,e=easeInOut(Math.min(1,T.t));
    const dx=DIRV[T.dir][0]*C*TILE,dy=DIRV[T.dir][1]*R*TILE;
    light(ORX+dx*(1-e)+(DOOR[OPP[T.dir]].ti+.5)*TILE,ORY+dy*(1-e)+(DOOR[OPP[T.dir]].tj+.5)*TILE,TILE*4.5,1);
  } else {
    for(const p of game.players)if(!p.down)light(ORX+p.x,ORY+p.y,TILE*4.6+flick,1);
    light(ORX+1.5*TILE,ORY+1.5*TILE,TILE*2,.55);
    light(ORX+(C-1.5)*TILE,ORY+1.5*TILE,TILE*2,.55);
    light(ORX+1.5*TILE,ORY+(R-1.5)*TILE,TILE*2,.55);
    light(ORX+(C-1.5)*TILE,ORY+(R-1.5)*TILE,TILE*2,.55);
    if(game.cur.type==='exit'||game.cur.type==='tower')light(ORX+8.5*TILE,ORY+5.5*TILE,TILE*2,.6);
    const boss=game.cur.live.find(e=>e.boss);
    if(boss)light(ORX+boss.x,ORY+boss.y,TILE*3,.7);
  }
  resetT(ctx);
  ctx.drawImage(lightCvs,0,0,VW,VH);
  if(game.clearFlash>0){
    ctx.fillStyle='rgba(255,209,102,'+game.clearFlash*.25+')';
    ctx.fillRect(0,0,VW,VH);
  }
  if(!game.trans){
    for(const [tx,ty] of [[1.5,1.25],[C-1.5,1.25],[1.5,R-1.25],[C-1.5,R-1.25]]){
      ctx.drawImage(SPR.torch,ORX+tx*TILE-TILE*.25,ORY+ty*TILE-TILE*.3,TILE*.5,TILE*.6);
    }
  }
  ctx.globalCompositeOperation='overlay';
  ctx.fillStyle=game.mode==='tower'?'rgba(95,138,74,.05)':'rgba(255,140,50,.05)';
  ctx.fillRect(0,0,VW,VH);
  ctx.globalCompositeOperation='source-over';
}

// ---------- HUD ----------
function drawHearts(P,x,y,hs){
  for(let i=0;i<P.maxhp/2;i++){
    let spr=SPR.heartEmpty;
    if(P.hp>=i*2+2)spr=SPR.heart;else if(P.hp===i*2+1)spr=SPR.heartHalf;
    ctx.drawImage(spr,x+i*(hs+4),y,hs,hs);
  }
}
function drawHUD(){
  resetT(ctx);
  const hgrad=ctx.createLinearGradient(0,0,0,HUDH);
  hgrad.addColorStop(0,'rgba(12,8,5,.85)');hgrad.addColorStop(1,'rgba(12,8,5,.55)');
  ctx.fillStyle=hgrad;
  ctx.fillRect(0,0,VW,HUDH-10);
  ctx.fillStyle='#57422c';ctx.fillRect(0,HUDH-11,VW,2);
  drawHearts(game.players[0],16,8,22);
  if(game.twoP){
    ctx.fillStyle='#8a7660';ctx.font='bold 10px Trebuchet MS';ctx.fillText('P2',16,42);
    drawHearts(game.players[1],34,30,16);
  }
  // hunger
  const bx=16,by=game.twoP?48:36,bw=160,bh=11;
  ctx.drawImage(SPR.meat,bx-4,by-6,22,22);
  ctx.fillStyle='#241a10';roundRect(ctx,bx+20,by,bw,bh,5);ctx.fill();
  ctx.strokeStyle='#57422c';ctx.lineWidth=1.5;ctx.stroke();
  const grd=ctx.createLinearGradient(bx+20,0,bx+20+bw,0);
  grd.addColorStop(0,'#d67f2e');grd.addColorStop(1,'#ffb54d');
  ctx.fillStyle=grd;roundRect(ctx,bx+22,by+2,Math.max(1,(bw-4)*(game.hunger/100)),bh-4,3);ctx.fill();
  // depth
  ctx.textAlign='right';
  ctx.font='800 19px Trebuchet MS';
  const label=game.mode==='tower'?'TOWER '+game.towerTier:'CAVE '+game.depth;
  ctx.fillStyle='rgba(0,0,0,.7)';ctx.fillText(label,VW-14,28);
  ctx.fillStyle=game.mode==='tower'?'#5f8a4a':'#ffa63e';ctx.fillText(label,VW-15,27);
  ctx.font='bold 11px Trebuchet MS';
  ctx.fillStyle='#8a7660';ctx.fillText('BONES '+game.kills,VW-15,44);
  ctx.textAlign='left';
  // materials pouch
  const pouchW=MATS.length*40+8;
  let mx=14,my=VH-(IS_TOUCH?128:56);
  ctx.fillStyle='rgba(12,8,5,.72)';roundRect(ctx,mx-6,my-16,pouchW,34,10);ctx.fill();
  ctx.strokeStyle='#57422c';ctx.lineWidth=1.5;ctx.stroke();
  ctx.font='bold 11px Trebuchet MS';
  for(const m of MATS){
    const n=game.mats[m]||0;
    ctx.globalAlpha=n>0?1:.3;
    ctx.drawImage(SPR[m],mx,my-12,20,20);
    ctx.fillStyle=n>0?'#e8d9c0':'#5a4c3c';
    ctx.fillText('×'+n,mx+18,my+5);
    ctx.globalAlpha=1;
    mx+=40;
  }
  // crafted passive tags
  let cxp=16;
  for(const r of REC){
    if(r.kind!=='passive'||!game.crafted[r.id])continue;
    ctx.fillStyle='rgba(193,100,42,.3)';roundRect(ctx,cxp-3,HUDH+2,34,15,6);ctx.fill();
    ctx.fillStyle='#d98443';ctx.font='bold 9px Trebuchet MS';
    ctx.fillText(r.name.split(' ')[0].slice(0,5),cxp,HUDH+13);
    cxp+=40;
  }
  // desktop tool slots
  if(!IS_TOUCH){
    const slotIcons={bola:SPR.bola,dart:SPR.obsidian,fist:SPR.rock};
    const labels=['Q','E'];
    for(let s2=0;s2<2;s2++){
      const bx2=VW-96+s2*48,by2=VH-46;
      drawToolSlot(bx2,by2,17,game.actives[s2],slotIcons,labels[s2]);
    }
    ctx.fillStyle='#8a7660';ctx.font='bold 12px Trebuchet MS';ctx.textAlign='right';
    ctx.fillText('[C] CRAFT',VW-16,VH-70);
    ctx.textAlign='left';
  }
}
function drawToolSlot(x,y,r,id,icons,label){
  ctx.fillStyle='rgba(12,8,5,.72)';ctx.beginPath();ctx.arc(x,y,r,0,7);ctx.fill();
  ctx.strokeStyle='#57422c';ctx.lineWidth=2;ctx.stroke();
  if(id){
    if(game.acd[id]>0){
      ctx.fillStyle='rgba(201,160,106,.35)';
      ctx.beginPath();ctx.moveTo(x,y);ctx.arc(x,y,r-1,-Math.PI/2,-Math.PI/2+6.28*(game.acd[id]/ACD_MAX[id]));ctx.closePath();ctx.fill();
    }
    ctx.drawImage(icons[id],x-r*.62,y-r*.68,r*1.24,r*1.24);
  } else {
    ctx.fillStyle='#4a3826';ctx.font='bold 14px Trebuchet MS';ctx.textAlign='center';
    ctx.fillText('·',x,y+4);ctx.textAlign='left';
  }
  ctx.fillStyle='#e8d9c0';ctx.font='bold 9px Trebuchet MS';ctx.textAlign='center';
  ctx.fillText(label,x,y+r+11);ctx.textAlign='left';
}

// ---------- touch UI ----------
function drawTouchUI(){
  resetT(ctx);
  touch.btns={};
  // move joystick zone (left)
  const jx=touch.moveId!==null?touch.moveOx:VW*.15;
  const jy=touch.moveId!==null?touch.moveOy:VH-100;
  ctx.globalAlpha=touch.moveId!==null?.5:.22;
  ctx.strokeStyle='#e8d9c0';ctx.lineWidth=2.5;
  ctx.beginPath();ctx.arc(jx,jy,50,0,7);ctx.stroke();
  ctx.fillStyle='#e8d9c0';
  ctx.beginPath();ctx.arc(jx+touch.moveDx,jy+touch.moveDy,22,0,7);ctx.fill();
  ctx.globalAlpha=1;
  // right side: aim stick (twin) or throw button (auto)
  if(aimMode==='twin'){
    const ax=touch.aimId!==null?touch.aimOx:VW*.85;
    const ay=touch.aimId!==null?touch.aimOy:VH-100;
    ctx.globalAlpha=touch.aimId!==null?.5:.22;
    ctx.strokeStyle='#ffa63e';ctx.lineWidth=2.5;
    ctx.beginPath();ctx.arc(ax,ay,50,0,7);ctx.stroke();
    ctx.fillStyle='#ffa63e';
    ctx.beginPath();ctx.arc(ax+touch.aimDx,ay+touch.aimDy,22,0,7);ctx.fill();
    ctx.globalAlpha=1;
  } else {
    const tx=VW-72,ty=VH-88;
    touch.btns.throw={x:tx,y:ty,r:38,tid:touch.btns.throw?touch.btns.throw.tid:null};
    ctx.globalAlpha=touch.firing?.85:.5;
    ctx.fillStyle='#c1642a';ctx.beginPath();ctx.arc(tx,ty,38,0,7);ctx.fill();
    ctx.drawImage(SPR.stone,tx-18,ty-18,36,36);
    ctx.globalAlpha=1;
  }
  // tool buttons
  const slotIcons={bola:SPR.bola,dart:SPR.obsidian,fist:SPR.rock};
  const t0x=aimMode==='twin'?VW-56:VW-140,t0y=aimMode==='twin'?VH-190:VH-70;
  const t1x=aimMode==='twin'?VW-116:VW-160,t1y=aimMode==='twin'?VH-170:VH-134;
  touch.btns.tool0={x:t0x,y:t0y,r:24};
  touch.btns.tool1={x:t1x,y:t1y,r:24};
  ctx.globalAlpha=.75;
  drawToolSlot(t0x,t0y,24,game.actives[0],slotIcons,'T1');
  drawToolSlot(t1x,t1y,24,game.actives[1],slotIcons,'T2');
  ctx.globalAlpha=1;
  // pause button
  const px2=44,py2=HUDH+30;
  touch.btns.pause={x:px2,y:py2,r:20};
  ctx.globalAlpha=.7;
  ctx.fillStyle='rgba(12,8,5,.8)';ctx.beginPath();ctx.arc(px2,py2,20,0,7);ctx.fill();
  ctx.strokeStyle='#8a7660';ctx.lineWidth=2;ctx.stroke();
  ctx.fillStyle='#e8d9c0';
  ctx.fillRect(px2-7,py2-8,5,16);ctx.fillRect(px2+2,py2-8,5,16);
  ctx.globalAlpha=1;
  // craft button
  const cx2=VW-44,cy2=HUDH+30;
  touch.btns.craft={x:cx2,y:cy2,r:22};
  ctx.globalAlpha=.75;
  ctx.fillStyle='rgba(12,8,5,.8)';ctx.beginPath();ctx.arc(cx2,cy2,22,0,7);ctx.fill();
  ctx.strokeStyle='#c1642a';ctx.lineWidth=2;ctx.stroke();
  ctx.drawImage(SPR.flint,cx2-13,cy2-13,26,26);
  ctx.fillStyle='#c1642a';ctx.font='bold 8px Trebuchet MS';ctx.textAlign='center';
  ctx.fillText('CRAFT',cx2,cy2+32);ctx.textAlign='left';
  ctx.globalAlpha=1;
}

// ---------- craft panel ----------
function craftPanelTap(clientX,clientY){
  const r=cvs.getBoundingClientRect();
  const x=clientX-r.left,y=clientY-r.top;
  for(const row of touch.panelRows){
    if(x>=row.x&&x<=row.x+row.w&&y>=row.y&&y<=row.y+row.h){
      if(row.close)game.craftOpen=false;
      else craft(row.i);
      return;
    }
  }
}
function drawCraftPanel(){
  touch.panelRows=[];
  if(!game.craftOpen)return;
  const pw=Math.min(660,VW-40),ph=Math.min(540,VH-50);
  const px=(VW-pw)/2,py=(VH-ph)/2;
  ctx.fillStyle='rgba(5,3,2,.85)';ctx.fillRect(0,0,VW,VH);
  ctx.fillStyle='#1c130c';roundRect(ctx,px,py,pw,ph,14);ctx.fill();
  ctx.strokeStyle='#57422c';ctx.lineWidth=3;ctx.stroke();
  ctx.strokeStyle='#c1642a';ctx.lineWidth=1;roundRect(ctx,px+5,py+5,pw-10,ph-10,10);ctx.stroke();
  ctx.textAlign='center';
  ctx.font='800 20px Trebuchet MS';
  ctx.fillStyle='#c1642a';ctx.fillText('KNAPPING & HAFTING',px+pw/2,py+30);
  ctx.font='10px Trebuchet MS';
  const np=REC.filter(x=>x.kind==='passive'&&game.crafted[x.id]).length;
  ctx.fillStyle='#8a7660';ctx.fillText('CRAFTS '+np+'/3 · TOOLS '+game.actives.length+'/2 · '+(IS_TOUCH?'TAP TO CRAFT':'[1-8] CRAFT · [C] CLOSE'),px+pw/2,py+48);
  ctx.textAlign='left';
  // close button
  const cbx=px+pw-28,cby=py+26;
  touch.panelRows.push({x:cbx-18,y:cby-18,w:36,h:36,close:true});
  ctx.strokeStyle='#8a7660';ctx.lineWidth=2.5;
  ctx.beginPath();ctx.moveTo(cbx-8,cby-8);ctx.lineTo(cbx+8,cby+8);ctx.moveTo(cbx+8,cby-8);ctx.lineTo(cbx-8,cby+8);ctx.stroke();
  const rowH=(ph-72)/REC.length;
  const compact=rowH<46;
  for(let i=0;i<REC.length;i++){
    const r=REC[i],y=py+62+i*rowH;
    const done=!!game.crafted[r.id];
    let can=!done;
    for(const m in r.cost)if((game.mats[m]||0)<r.cost[m])can=false;
    if(r.kind==='active'&&game.actives.length>=2&&!done)can=false;
    if(r.kind==='passive'&&np>=3&&!done)can=false;
    touch.panelRows.push({x:px+10,y:y-12,w:pw-20,h:rowH-4,i});
    ctx.globalAlpha=done?.45:can?1:.6;
    if(can&&!done){ctx.fillStyle='rgba(193,100,42,.14)';roundRect(ctx,px+12,y-11,pw-24,rowH-6,8);ctx.fill();}
    ctx.fillStyle=r.kind==='active'?'#5f8a4a':'#8a7660';
    ctx.font='bold 8px Trebuchet MS';
    ctx.fillText(r.kind==='active'?'TOOL':'CRAFT',px+22,y-1);
    ctx.fillStyle=done?'#6b5236':can?'#ffa63e':'#8a7660';
    ctx.font='bold '+(compact?12:14)+'px Trebuchet MS';
    ctx.fillText((IS_TOUCH?'':'['+(i+1)+'] ')+r.name,px+22,y+13);
    let ix=px+pw*.4;
    for(const m in r.cost){
      ctx.drawImage(SPR[m],ix,y-4,18,18);
      const have=(game.mats[m]||0)>=r.cost[m];
      ctx.fillStyle=have?'#e8d9c0':'#c8402e';
      ctx.font='bold 10px Trebuchet MS';
      ctx.fillText((game.mats[m]||0)+'/'+r.cost[m],ix+18,y+9);
      ix+=48;
    }
    ctx.fillStyle=done?'#5f8a4a':'#c9a06a';
    ctx.font='bold 9px Trebuchet MS';
    ctx.fillText(done?'MADE':r.fx,px+pw*.68,y+9);
    if(!compact){
      ctx.fillStyle='#8a7660';ctx.font='italic 10px Trebuchet MS';
      ctx.fillText(r.lore,px+22,y+27);
    }
    ctx.globalAlpha=1;
  }
}

// ---------- minimap ----------
function drawMinimap(){
  if(game.mode==='tower'){
    ctx.textAlign='right';
    ctx.font='bold 11px Trebuchet MS';
    ctx.fillStyle='#5f8a4a';
    ctx.fillText('— THE FIRST TOWER —',VW-16,HUDH+16);
    ctx.textAlign='left';
    return;
  }
  const rooms=game.rooms;
  const cw=13,ch=9,gap=3;
  let known=[];
  for(const k in rooms){
    const r=rooms[k];
    if(r.visited){known.push(r);continue;}
    for(const d of ['n','s','w','e']){
      const n=rooms[key(r.gx+DIRV[d][0],r.gy+DIRV[d][1])];
      if(n&&n.visited){known.push(r);break;}
    }
  }
  if(!known.length)return;
  let minx=1e9,miny=1e9,maxx=-1e9,maxy=-1e9;
  for(const r of known){minx=Math.min(minx,r.gx);maxx=Math.max(maxx,r.gx);miny=Math.min(miny,r.gy);maxy=Math.max(maxy,r.gy);}
  const mw=(maxx-minx+1)*(cw+gap),mh=(maxy-miny+1)*(ch+gap);
  const px=VW-mw-(IS_TOUCH?76:16),py=HUDH+4;
  ctx.fillStyle='rgba(12,8,5,.6)';roundRect(ctx,px-6,py-6,mw+12,mh+12,8);ctx.fill();
  ctx.strokeStyle='#57422c';ctx.lineWidth=1.5;ctx.stroke();
  for(const r of known){
    const x=px+(r.gx-minx)*(cw+gap),y=py+(r.gy-miny)*(ch+gap);
    const cur=r===game.cur;
    if(r.visited){
      ctx.fillStyle=cur?'#ffa63e':'#6b5236';
      roundRect(ctx,x,y,cw,ch,2);ctx.fill();
    } else {
      ctx.strokeStyle='#4a3826';ctx.lineWidth=1.5;roundRect(ctx,x+.5,y+.5,cw-1,ch-1,2);ctx.stroke();
    }
    let icon=null;
    if(r.type==='treasure')icon='#b9c6cf';
    else if(r.type==='exit')icon='#000';
    else if(r.type==='grok')icon='#8ac24a';
    else if(r.type==='shrine')icon='#c1642a';
    if(icon){
      ctx.fillStyle=icon;
      ctx.beginPath();ctx.arc(x+cw/2,y+ch/2,2,0,7);ctx.fill();
    }
  }
}

resize();
